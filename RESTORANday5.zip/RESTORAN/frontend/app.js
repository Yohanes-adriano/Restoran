/**
 * ADRIANO RESTO - CLIENT APPLICATION
 * Clean, fast, and authentic restaurant ordering system.
 */

// Configuration
const API_BASE_URL = (typeof window !== "undefined" && window.location.origin && window.location.origin.startsWith("http")) 
    ? `${window.location.origin}/api` 
    : "http://127.0.0.1:3000/api";

// Application State
const state = {
    menuItems: [],
    categories: [],
    stats: null,
    featuredItems: [],
    pagination: {
        totalItems: 0,
        totalPages: 1,
        currentPage: 1,
        limit: 12,
        hasNextPage: false,
        hasPrevPage: false
    },
    filters: {
        category: "all",
        search: "",
        maxPrice: 350000,
        badge: "",
        sortBy: "id",
        order: "DESC"
    },
    viewMode: "grid", // 'grid' | 'list'
    cart: JSON.parse(localStorage.getItem("adriano_cart") || localStorage.getItem("laura_cart") || "[]"),
    orderHistory: JSON.parse(localStorage.getItem("adriano_orders") || localStorage.getItem("laura_orders") || "[]"),
    searchDebounceTimer: null
};

// Currency Formatter (Indonesian Rupiah)
const formatRupiah = (number) => {
    return new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR",
        maximumFractionDigits: 0
    }).format(number);
};

// ==================== INITIALIZATION ====================
document.addEventListener("DOMContentLoaded", () => {
    initApp();
    setupEventListeners();
    updateCartUI();
});

async function initApp() {
    await Promise.all([
        fetchStats(),
        fetchCategories(),
        fetchMenuItems()
    ]);
}

// ==================== API FETCHERS ====================

/**
 * Fetch Restaurant Stats & Highlights
 */
async function fetchStats() {
    try {
        const res = await fetch(`${API_BASE_URL}/menu/stats`);
        const json = await res.json();
        if (json.success) {
            state.stats = json.stats;
            state.featuredItems = json.featured || json.bestSellers || [];
            renderFeaturedCarousel(state.featuredItems);
        }
    } catch (err) {
        console.error("Failed to load restaurant stats:", err);
    }
}

/**
 * Fetch Categories with live counts
 */
async function fetchCategories() {
    try {
        const res = await fetch(`${API_BASE_URL}/menu/categories`);
        const json = await res.json();
        if (json.success) {
            state.categories = json.data;
            renderCategoryTabs(json.data);
        }
    } catch (err) {
        console.error("Failed to load categories:", err);
    }
}

/**
 * Fetch Menu Items with filters, search, and pagination
 */
async function fetchMenuItems() {
    const grid = document.getElementById("menuGrid");
    grid.innerHTML = `
        <div class="loading-state" style="grid-column: 1 / -1;">
            <div class="spinner"></div>
            <p>Menyiapkan daftar hidangan...</p>
        </div>
    `;

    try {
        const params = new URLSearchParams({
            page: state.pagination.currentPage,
            limit: state.pagination.limit,
            sort_by: state.filters.sortBy,
            order: state.filters.order
        });

        if (state.filters.category && state.filters.category !== "all") {
            params.append("kategori", state.filters.category);
        }
        if (state.filters.search) {
            params.append("search", state.filters.search);
        }
        if (state.filters.maxPrice) {
            params.append("max_price", state.filters.maxPrice);
        }
        if (state.filters.badge) {
            params.append("badge", state.filters.badge);
        }

        const res = await fetch(`${API_BASE_URL}/menu?${params.toString()}`);
        const json = await res.json();

        if (json.success) {
            state.menuItems = json.data;
            state.pagination = json.pagination;
            renderMenuGrid(json.data);
            renderPagination(json.pagination);
            updateResultsCount(json.pagination.totalItems);
        } else {
            showEmptyState("Gagal memuat menu: " + json.message);
        }
    } catch (err) {
        console.error("Failed to load menu:", err);
        showEmptyState("Tidak dapat terhubung ke server API. Pastikan server backend sedang aktif.");
    }
}

// ==================== RENDERING FUNCTIONS ====================

/**
 * Render Highlights Carousel
 */
function renderFeaturedCarousel(items) {
    const carousel = document.getElementById("featuredCarousel");
    if (!items || items.length === 0) {
        carousel.innerHTML = "<p style='color: var(--text-muted); padding: 1rem;'>Belum ada menu pilihan saat ini.</p>";
        return;
    }

    carousel.innerHTML = items.map(item => `
        <div class="featured-card" onclick="openMenuDetailModal(${item.id})">
            <div class="card-img-wrapper">
                <img src="${item.gambar}" alt="${item.nama}" class="card-img" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'">
                ${renderBadge(item.badge)}
                <span class="card-rating-chip">★ ${parseFloat(item.rating).toFixed(1)}</span>
            </div>
            <div class="card-body">
                <div class="card-category-text">${item.kategori}</div>
                <h3 class="card-title">${item.nama}</h3>
                <div class="card-meta-row">
                    <span>🔥 Terjual ${item.total_terjual || 0} porsi</span>
                </div>
            </div>
            <div class="card-footer">
                <div class="card-price">${formatRupiah(item.harga)}</div>
                <button class="btn-card-add" onclick="event.stopPropagation(); addToCart(${item.id})" title="Tambah ke Pesanan">
                    <span>+ Tambah</span>
                </button>
            </div>
        </div>
    `).join("");
}

function renderBadge(badge) {
    if (!badge) return "";
    let badgeClass = "card-badge-chip";
    if (badge.includes("Best Seller") || badge.includes("Laris")) badgeClass += " best-seller";
    else if (badge.includes("Chef") || badge.includes("Rekomendasi")) badgeClass += " chef";
    else if (badge.includes("Promo")) badgeClass += " promo";
    return `<span class="${badgeClass}">${badge}</span>`;
}

/**
 * Render Category Filter Pills
 */
function renderCategoryTabs(categories) {
    const container = document.getElementById("categoryTabsContainer");

    const icons = {
        "Nusantara": "🍛",
        "Western & Grill": "🥩",
        "Pasta & Pizza": "🍕",
        "Asian & Japanese": "🍜",
        "Seafood": "🦐",
        "Dessert & Pastry": "🍰",
        "Beverages & Coffee": "☕",
        "Snacks & Appetizers": "🍟",
        "Healthy & Salad": "🥗",
        "Soup & Hotpot": "🍲"
    };

    const totalAll = categories.reduce((sum, c) => sum + parseInt(c.total_items, 10), 0);
    const countAllEl = document.getElementById("countAll");
    if (countAllEl) countAllEl.textContent = totalAll;

    const tabsHtml = categories.map(cat => `
        <button class="cat-tab-btn cat-pill ${state.filters.category === cat.kategori ? 'active' : ''}" data-category="${cat.kategori}">
            <span class="cat-icon">${icons[cat.kategori] || "🍽️"}</span>
            <span class="cat-label">${cat.kategori}</span>
            <span class="cat-badge">${cat.total_items}</span>
        </button>
    `).join("");

    const allBtnHtml = `
        <button class="cat-tab-btn cat-pill ${state.filters.category === 'all' ? 'active' : ''}" data-category="all" id="catAllBtn">
            <span class="cat-icon">🍽️</span>
            <span class="cat-label">Semua Menu</span>
            <span class="cat-badge" id="countAll">${totalAll}</span>
        </button>
    `;

    container.innerHTML = allBtnHtml + tabsHtml;

    container.querySelectorAll(".cat-pill, .cat-tab-btn").forEach(pill => {
        pill.addEventListener("click", () => {
            container.querySelectorAll(".cat-pill, .cat-tab-btn").forEach(p => p.classList.remove("active"));
            pill.classList.add("active");
            state.filters.category = pill.getAttribute("data-category");
            state.pagination.currentPage = 1;
            fetchMenuItems();
        });
    });
}

/**
 * Render Menu Catalog Grid
 */
function renderMenuGrid(items) {
    const grid = document.getElementById("menuGrid");

    if (!items || items.length === 0) {
        showEmptyState("Tidak ada menu yang cocok dengan kata kunci atau filter Anda.");
        return;
    }

    grid.innerHTML = items.map(item => `
        <div class="menu-card" data-id="${item.id}">
            <div class="card-img-wrapper" onclick="openMenuDetailModal(${item.id})" style="cursor: pointer;">
                <img src="${item.gambar}" alt="${item.nama}" class="card-img" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'">
                ${renderBadge(item.badge)}
                <span class="card-rating-chip">★ ${parseFloat(item.rating).toFixed(1)}</span>
            </div>
            <div class="card-body">
                <div class="card-category-text">${item.kategori}</div>
                <h3 class="card-title" onclick="openMenuDetailModal(${item.id})" style="cursor: pointer;">${item.nama}</h3>
                <p class="card-desc">${item.deskripsi || "Masakan khas olahan bumbu pilihan, disajikan hangat dengan cita rasa pas di lidah."}</p>
                <div class="card-meta-row">
                    <span>⏱️ ~${item.estimasi_menit || 15} Menit</span>
                    ${item.kalori ? `<span>• 🔥 ${item.kalori} kkal</span>` : ""}
                    <span>• Terjual ${item.total_terjual || 0}</span>
                </div>
            </div>
            <div class="card-footer">
                <div class="card-price">${formatRupiah(item.harga)}</div>
                <div style="display: flex; gap: 0.4rem;">
                    <button class="btn-card-detail" onclick="openMenuDetailModal(${item.id})" title="Lihat Rincian Menu">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                    </button>
                    <button class="btn-card-add" onclick="addToCart(${item.id})">
                        <span>+ Tambah</span>
                    </button>
                </div>
            </div>
        </div>
    `).join("");
}

function showEmptyState(message) {
    const grid = document.getElementById("menuGrid");
    grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 3.5rem 1rem;">
            <div style="font-size: 3rem; margin-bottom: 0.75rem; opacity: 0.6;">🍽️</div>
            <h3 style="font-family: var(--font-heading); font-size: 1.35rem; margin-bottom: 0.35rem; color: #fff;">Menu Tidak Ditemukan</h3>
            <p style="color: var(--text-muted); max-width: 440px; margin: 0 auto 1.25rem; font-size: 0.88rem;">${message}</p>
            <button class="btn-primary-small" onclick="resetFilters()">Reset Filter & Lihat Semua Menu</button>
        </div>
    `;
}

function updateResultsCount(total) {
    const info = document.getElementById("resultsCountInfo");
    if (!info) return;

    const start = (state.pagination.currentPage - 1) * state.pagination.limit + 1;
    const end = Math.min(start + state.pagination.limit - 1, total);

    if (total === 0) {
        info.textContent = "0 menu ditemukan";
    } else {
        info.innerHTML = `Menampilkan <strong>${start} - ${end}</strong> dari <strong>${total.toLocaleString('id-ID')}</strong> Menu`;
    }
}

/**
 * Render Numeric Pagination
 */
function renderPagination(p) {
    const prevBtn = document.getElementById("btnPrevPage");
    const nextBtn = document.getElementById("btnNextPage");
    const list = document.getElementById("pageNumbersList");

    prevBtn.disabled = !p.hasPrevPage;
    nextBtn.disabled = !p.hasNextPage;

    const current = p.currentPage;
    const total = p.totalPages;
    let pages = [];

    if (total <= 7) {
        for (let i = 1; i <= total; i++) pages.push(i);
    } else {
        pages.push(1);
        if (current > 3) pages.push("...");
        
        let start = Math.max(2, current - 1);
        let end = Math.min(total - 1, current + 1);
        
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }

        if (current < total - 2) pages.push("...");
        pages.push(total);
    }

    list.innerHTML = pages.map(item => {
        if (item === "...") {
            return `<span class="page-dots">...</span>`;
        }
        return `
            <button class="page-btn-num ${item === current ? 'active' : ''}" onclick="goToPage(${item})">
                ${item}
            </button>
        `;
    }).join("");
}

function goToPage(page) {
    state.pagination.currentPage = page;
    fetchMenuItems();
    document.getElementById("catalogSection").scrollIntoView({ behavior: "smooth" });
}

// ==================== CART & ORDER MANAGEMENT ====================

function addToCart(itemId, qty = 1, notes = "") {
    let item = state.menuItems.find(m => m.id === itemId);
    if (!item) {
        item = state.featuredItems.find(m => m.id === itemId);
    }

    if (!item) {
        showToast("Menu tidak ditemukan", "error");
        return;
    }

    const existingIndex = state.cart.findIndex(c => c.id === itemId);
    if (existingIndex > -1) {
        state.cart[existingIndex].qty += qty;
        if (notes) state.cart[existingIndex].catatan = notes;
    } else {
        state.cart.push({
            id: item.id,
            nama: item.nama,
            kategori: item.kategori,
            harga: parseFloat(item.harga),
            gambar: item.gambar,
            qty: qty,
            catatan: notes || ""
        });
    }

    saveCart();
    updateCartUI();
    showToast(`"${item.nama}" dimasukkan ke pesanan`);
}

function updateCartQty(itemId, delta) {
    const item = state.cart.find(c => c.id === itemId);
    if (!item) return;

    item.qty += delta;
    if (item.qty <= 0) {
        state.cart = state.cart.filter(c => c.id !== itemId);
    }

    saveCart();
    updateCartUI();
}

function removeCartItem(itemId) {
    state.cart = state.cart.filter(c => c.id !== itemId);
    saveCart();
    updateCartUI();
    showToast("Menu dihapus dari pesanan");
}

function saveCart() {
    localStorage.setItem("adriano_cart", JSON.stringify(state.cart));
}

function updateCartUI() {
    const countBadge = document.getElementById("cartCountBadge");
    const totalHeader = document.getElementById("cartTotalHeader");
    const itemsList = document.getElementById("cartItemsList");
    const subtitle = document.getElementById("cartItemsSubtitle");

    const totalQty = state.cart.reduce((sum, item) => sum + item.qty, 0);
    const subtotal = state.cart.reduce((sum, item) => sum + (item.harga * item.qty), 0);
    const tax = Math.round(subtotal * 0.10); // 10% PB1
    const serviceFee = Math.round(subtotal * 0.05); // 5% Service Charge
    const grandTotal = subtotal + tax + serviceFee;

    countBadge.textContent = totalQty;
    totalHeader.textContent = formatRupiah(grandTotal);
    subtitle.textContent = `${totalQty} Menu Dipilih`;

    document.getElementById("cartSubtotal").textContent = formatRupiah(subtotal);
    document.getElementById("cartTax").textContent = formatRupiah(tax);
    document.getElementById("cartService").textContent = formatRupiah(serviceFee);
    document.getElementById("cartGrandTotal").textContent = formatRupiah(grandTotal);
    document.getElementById("btnCheckoutTotalLabel").textContent = formatRupiah(grandTotal);

    if (state.cart.length === 0) {
        itemsList.innerHTML = `
            <div class="empty-cart-state">
                <div class="empty-cart-icon">🛒</div>
                <h4>Belum Ada Menu yang Dipilih</h4>
                <p>Silakan pilih hidangan favorit Anda dari daftar menu kami.</p>
                <button class="btn-primary-small" onclick="closeCartDrawer()">Lihat Daftar Menu</button>
            </div>
        `;
        document.getElementById("btnProceedCheckout").disabled = true;
        document.getElementById("btnProceedCheckout").style.opacity = "0.5";
    } else {
        document.getElementById("btnProceedCheckout").disabled = false;
        document.getElementById("btnProceedCheckout").style.opacity = "1";

        itemsList.innerHTML = state.cart.map(item => `
            <div class="cart-item-row">
                <img src="${item.gambar}" alt="${item.nama}" class="cart-item-img" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'">
                <div class="cart-item-info">
                    <div class="cart-item-title">${item.nama}</div>
                    <div class="cart-item-price">${formatRupiah(item.harga)}</div>
                    ${item.catatan ? `<div style="font-size: 0.72rem; color: var(--text-muted); margin-bottom: 0.2rem;">Catatan: ${item.catatan}</div>` : ""}
                    <div class="cart-qty-row">
                        <button class="qty-btn" onclick="updateCartQty(${item.id}, -1)">-</button>
                        <span class="qty-value">${item.qty}</span>
                        <button class="qty-btn" onclick="updateCartQty(${item.id}, 1)">+</button>
                        <button class="btn-remove-item" onclick="removeCartItem(${item.id})" title="Hapus">&times;</button>
                    </div>
                </div>
            </div>
        `).join("");
    }
}

/**
 * Handle Order Checkout via API
 */
async function processOrderCheckout() {
    if (state.cart.length === 0) {
        showToast("Pesanan Anda masih kosong", "error");
        return;
    }

    const nameInput = document.getElementById("orderCustomerName");
    const phoneInput = document.getElementById("orderCustomerPhone");
    const tableSelect = document.getElementById("orderTableNumber");
    const paymentSelect = document.getElementById("orderPaymentMethod");

    const customerName = nameInput.value.trim();
    if (!customerName) {
        showToast("Mohon masukkan nama pemesan terlebih dahulu", "error");
        nameInput.focus();
        return;
    }

    const checkoutBtn = document.getElementById("btnProceedCheckout");
    checkoutBtn.disabled = true;
    checkoutBtn.innerHTML = `<span>Mengirim ke Dapur...</span>`;

    try {
        const orderPayload = {
            customer_name: customerName,
            customer_phone: phoneInput.value.trim() || "-",
            table_number: tableSelect.value,
            payment_method: paymentSelect.value,
            notes: "Pemesanan via Website Adriano Resto",
            items: state.cart.map(c => ({
                id: c.id,
                nama: c.nama,
                harga: c.harga,
                jumlah: c.qty,
                catatan: c.catatan
            }))
        };

        const res = await fetch(`${API_BASE_URL}/orders`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(orderPayload)
        });

        const json = await res.json();

        if (json.success) {
            state.orderHistory.unshift(json.order);
            localStorage.setItem("adriano_orders", JSON.stringify(state.orderHistory));

            state.cart = [];
            saveCart();
            updateCartUI();
            closeCartDrawer();

            showOrderReceipt(json.order);
            showToast("Pesanan berhasil dibuat!", "success");
        } else {
            showToast("Gagal: " + json.message, "error");
        }
    } catch (err) {
        console.error("Checkout error:", err);
        showToast("Gagal memproses pesanan. Periksa koneksi ke server.", "error");
    } finally {
        checkoutBtn.disabled = false;
        updateCartUI();
    }
}

/**
 * Display Order Receipt Invoice Modal
 */
function showOrderReceipt(order) {
    const content = document.getElementById("receiptContent");

    content.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.65rem; margin-bottom: 0.85rem; padding-bottom: 0.85rem; border-bottom: 1px dashed var(--border-subtle);">
            <div>
                <span style="color: var(--text-subtle); font-size: 0.75rem;">No. Pesanan:</span><br>
                <strong style="color: var(--primary); font-size: 0.95rem;">${order.order_number}</strong>
            </div>
            <div>
                <span style="color: var(--text-subtle); font-size: 0.75rem;">Nama Pemesan:</span><br>
                <strong>${order.customer_name}</strong>
            </div>
            <div>
                <span style="color: var(--text-subtle); font-size: 0.75rem;">Meja / Lokasi:</span><br>
                <span>${order.table_number}</span>
            </div>
            <div>
                <span style="color: var(--text-subtle); font-size: 0.75rem;">Metode Bayar:</span><br>
                <span>${order.payment_method}</span>
            </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 0.85rem; font-size: 0.82rem;">
            <thead>
                <tr style="border-bottom: 1px solid var(--border-subtle); text-align: left; color: var(--text-muted);">
                    <th style="padding: 0.35rem 0;">Menu</th>
                    <th style="text-align: center;">Jml</th>
                    <th style="text-align: right;">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                ${order.items.map(item => `
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.04);">
                        <td style="padding: 0.45rem 0;">
                            <strong>${item.nama}</strong>
                            ${item.catatan ? `<div style="font-size: 0.7rem; color: var(--text-muted);">${item.catatan}</div>` : ""}
                        </td>
                        <td style="text-align: center;">${item.jumlah}x</td>
                        <td style="text-align: right; font-weight: 600;">${formatRupiah(item.subtotal)}</td>
                    </tr>
                `).join("")}
            </tbody>
        </table>

        <div style="display: flex; flex-direction: column; gap: 0.25rem; font-size: 0.82rem; color: var(--text-muted);">
            <div style="display: flex; justify-content: space-between;">
                <span>Subtotal Menu</span>
                <span>${formatRupiah(order.subtotal)}</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span>Pajak Restoran PB1 (10%)</span>
                <span>${formatRupiah(order.tax)}</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span>Biaya Layanan (5%)</span>
                <span>${formatRupiah(order.service_fee)}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 1rem; font-weight: 800; color: #fff; padding-top: 0.5rem; border-top: 1px dashed var(--border-subtle);">
                <span>Total Bayar</span>
                <span style="color: var(--primary);">${formatRupiah(order.total_amount)}</span>
            </div>
        </div>
    `;

    openModal("receiptModal", "receiptModalBackdrop");
}

// ==================== MENU DETAIL MODAL ====================

async function openMenuDetailModal(menuId) {
    const modalContent = document.getElementById("detailModalContent");
    modalContent.innerHTML = `
        <div class="loading-state">
            <div class="spinner"></div>
            <p>Memuat informasi hidangan...</p>
        </div>
    `;
    openModal("detailModal", "detailModalBackdrop");

    try {
        const res = await fetch(`${API_BASE_URL}/menu/${menuId}`);
        const json = await res.json();

        if (json.success) {
            const m = json.data;
            const related = json.relatedItems || [];

            modalContent.innerHTML = `
                <img src="${m.gambar}" alt="${m.nama}" class="detail-dialog-img" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'">
                
                <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.5rem;">
                    <span style="font-size: 0.72rem; font-weight: 700; color: var(--primary); text-transform: uppercase;">${m.kategori}</span>
                    ${m.badge ? `<span style="font-size: 0.72rem; padding: 0.15rem 0.5rem; background: rgba(226,92,52,0.15); border-radius: 4px; color: var(--primary); font-weight: 700;">${m.badge}</span>` : ""}
                    <span style="font-size: 0.75rem; color: var(--amber); font-weight: 700;">★ ${parseFloat(m.rating).toFixed(1)} / 5.0</span>
                    <span style="font-size: 0.75rem; color: var(--text-muted);">• ${m.total_terjual || 0} porsi terjual</span>
                </div>

                <h2 style="font-family: var(--font-heading); font-size: 1.45rem; font-weight: 800; color: #fff; line-height: 1.25;">${m.nama}</h2>
                <div class="detail-price-lg">${formatRupiah(m.harga)}</div>

                <p style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.55; margin-bottom: 1rem;">${m.deskripsi || "Masakan khas olahan bumbu pilihan, disajikan hangat dengan cita rasa pas di lidah."}</p>

                <div style="display: flex; gap: 1rem; font-size: 0.8rem; color: var(--text-subtle); margin-bottom: 1rem; padding: 0.65rem 0.85rem; background: var(--bg-input); border-radius: 8px;">
                    <span>⏱️ Masak: <strong>~${m.estimasi_menit || 15} Menit</strong></span>
                    ${m.kalori ? `<span>🔥 Kalori: <strong>${m.kalori} kkal</strong></span>` : ""}
                    <span>Status: <strong style="color: ${m.is_tersedia ? 'var(--green)' : 'var(--danger)'};">${m.is_tersedia ? 'Tersedia' : 'Habis'}</strong></span>
                </div>

                <div class="form-group" style="margin-bottom: 1rem;">
                    <label for="modalDetailNotes" style="font-size: 0.78rem; font-weight: 600; color: var(--text-muted);">Catatan untuk Dapur (Opsi):</label>
                    <input type="text" id="modalDetailNotes" placeholder="Contoh: Kurangi minyak, cabai dipisah..." style="background: var(--bg-input); border: 1px solid var(--border-subtle); border-radius: 6px; padding: 0.5rem 0.75rem; color: #fff; font-size: 0.82rem; width: 100%;">
                </div>

                <div style="display: flex; align-items: center; gap: 0.75rem; margin-top: 0.5rem;">
                    <div class="cart-qty-row">
                        <button class="qty-btn" id="modalQtyMinus">-</button>
                        <span class="qty-value" id="modalQtyValue">1</span>
                        <button class="qty-btn" id="modalQtyPlus">+</button>
                    </div>
                    <button class="btn-solid" id="btnModalAddToCart" style="flex: 1; padding: 0.7rem; font-size: 0.9rem;">
                        Tambah ke Pesanan • <span id="modalTotalBtn">${formatRupiah(m.harga)}</span>
                    </button>
                </div>

                ${related.length > 0 ? `
                    <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--border-subtle);">
                        <h4 style="font-size: 0.85rem; font-weight: 700; color: var(--text-muted); margin-bottom: 0.75rem;">Menu Terkait di Kategori ${m.kategori}:</h4>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(110px, 1fr)); gap: 0.65rem;">
                            ${related.map(r => `
                                <div onclick="openMenuDetailModal(${r.id})" style="background: var(--bg-input); border: 1px solid var(--border-subtle); border-radius: 8px; padding: 0.5rem; cursor: pointer; text-align: center;">
                                    <img src="${r.gambar}" alt="${r.nama}" style="width: 100%; height: 60px; object-fit: cover; border-radius: 6px; margin-bottom: 0.35rem;" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'">
                                    <span style="font-size: 0.72rem; font-weight: 700; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #fff;">${r.nama}</span>
                                    <small style="color: var(--text-main); font-size: 0.7rem;">${formatRupiah(r.harga)}</small>
                                </div>
                            `).join("")}
                        </div>
                    </div>
                ` : ""}
            `;

            let currentQty = 1;
            const qtyVal = document.getElementById("modalQtyValue");
            const btnTotal = document.getElementById("modalTotalBtn");

            document.getElementById("modalQtyMinus").onclick = () => {
                if (currentQty > 1) {
                    currentQty--;
                    qtyVal.textContent = currentQty;
                    btnTotal.textContent = formatRupiah(m.harga * currentQty);
                }
            };
            document.getElementById("modalQtyPlus").onclick = () => {
                currentQty++;
                qtyVal.textContent = currentQty;
                btnTotal.textContent = formatRupiah(m.harga * currentQty);
            };

            document.getElementById("btnModalAddToCart").onclick = () => {
                const notes = document.getElementById("modalDetailNotes").value.trim();
                addToCart(m.id, currentQty, notes);
                closeModal("detailModal", "detailModalBackdrop");
            };
        }
    } catch (err) {
        modalContent.innerHTML = `<p style="color: var(--danger); padding: 1rem;">Gagal memuat rincian: ${err.message}</p>`;
    }
}

// ==================== ADMIN ADD MENU ====================

async function handleAdminCreateMenu(e) {
    e.preventDefault();
    const nama = document.getElementById("adminMenuNama").value.trim();
    const kategori = document.getElementById("adminMenuKategori").value;
    const harga = document.getElementById("adminMenuHarga").value;
    const badge = document.getElementById("adminMenuBadge").value || null;
    const gambar = document.getElementById("adminMenuGambar").value.trim() || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80";
    const deskripsi = document.getElementById("adminMenuDeskripsi").value.trim();
    const kalori = document.getElementById("adminMenuKalori").value || null;
    const estimasi = document.getElementById("adminMenuEstimasi").value || 15;

    const saveBtn = document.getElementById("btnSaveAdminMenu");
    saveBtn.disabled = true;
    saveBtn.textContent = "Menyimpan ke Database...";

    try {
        const res = await fetch(`${API_BASE_URL}/menu`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                nama,
                kategori,
                harga: parseFloat(harga),
                badge,
                gambar,
                deskripsi,
                kalori: kalori ? parseInt(kalori, 10) : null,
                estimasi_menit: parseInt(estimasi, 10)
            })
        });

        const json = await res.json();
        if (json.success) {
            showToast(`Menu baru "${nama}" berhasil ditambahkan!`, "success");
            closeModal("adminModal", "adminModalBackdrop");
            document.getElementById("adminMenuForm").reset();
            fetchCategories();
            fetchMenuItems();
            fetchStats();
        } else {
            showToast("Gagal: " + json.message, "error");
        }
    } catch (err) {
        showToast("Error: " + err.message, "error");
    } finally {
        saveBtn.disabled = false;
        saveBtn.textContent = "Simpan Menu Baru";
    }
}

// ==================== TRACK ORDERS MODAL ====================

async function openTrackOrderModal() {
    const body = document.getElementById("trackModalBody");
    body.innerHTML = `
        <div class="loading-state">
            <div class="spinner"></div>
            <p>Memeriksa status pesanan...</p>
        </div>
    `;
    openModal("trackModal", "trackModalBackdrop");

    try {
        const res = await fetch(`${API_BASE_URL}/orders?limit=15`);
        const json = await res.json();

        if (json.success && json.data.length > 0) {
            body.innerHTML = json.data.map(order => `
                <div style="background: var(--bg-input); border: 1px solid var(--border-subtle); border-radius: 8px; padding: 1rem; margin-bottom: 0.75rem; display: flex; align-items: center; justify-content: space-between;">
                    <div>
                        <div style="font-size: 0.78rem; color: var(--primary); font-weight: 700;">${order.order_number}</div>
                        <strong style="font-size: 0.95rem; color: #fff;">${order.customer_name}</strong>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">${order.table_number} • ${order.payment_method}</div>
                        <div style="font-size: 0.78rem; color: var(--text-main); margin-top: 0.2rem;">Total: <strong>${formatRupiah(order.total_amount)}</strong></div>
                    </div>
                    <div>
                        <span style="padding: 0.3rem 0.65rem; border-radius: 4px; font-size: 0.75rem; font-weight: 700; ${order.status === 'pending' ? 'background: rgba(245,158,11,0.15); color: #f59e0b; border: 1px solid #f59e0b;' : order.status === 'proses' ? 'background: rgba(59,130,246,0.15); color: #60a5fa; border: 1px solid #3b82f6;' : 'background: rgba(34,197,94,0.15); color: #22c55e; border: 1px solid #22c55e;'}">
                            ${order.status === 'pending' ? '⏳ Menunggu Antrean' : order.status === 'proses' ? '🍳 Sedang Dimasak' : order.status === 'selesai' ? '✅ Selesai' : 'Dibatalkan'}
                        </span>
                    </div>
                </div>
            `).join("");
        } else {
            body.innerHTML = `
                <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
                    <p>Belum ada riwayat pesanan.</p>
                </div>
            `;
        }
    } catch (err) {
        body.innerHTML = `<p style="color: var(--danger); padding: 1rem;">Gagal memuat status: ${err.message}</p>`;
    }
}

// ==================== EVENT LISTENERS & HELPERS ====================

function setupEventListeners() {
    const searchInput = document.getElementById("searchInput");
    const clearBtn = document.getElementById("btnClearSearch");

    searchInput.addEventListener("input", (e) => {
        const val = e.target.value;
        clearBtn.style.display = val ? "block" : "none";

        clearTimeout(state.searchDebounceTimer);
        state.searchDebounceTimer = setTimeout(() => {
            state.filters.search = val.trim();
            state.pagination.currentPage = 1;
            fetchMenuItems();
        }, 350);
    });

    clearBtn.addEventListener("click", () => {
        searchInput.value = "";
        clearBtn.style.display = "none";
        state.filters.search = "";
        state.pagination.currentPage = 1;
        fetchMenuItems();
    });

    document.getElementById("btnSubmitSearch").addEventListener("click", () => {
        state.filters.search = searchInput.value.trim();
        state.pagination.currentPage = 1;
        fetchMenuItems();
    });

    // Keyboard shortcut: Press '/' to focus search
    window.addEventListener("keydown", (e) => {
        if (e.key === "/" && document.activeElement.tagName !== "INPUT" && document.activeElement.tagName !== "TEXTAREA") {
            e.preventDefault();
            focusSearchInput();
        }
    });

    // Sorting
    document.getElementById("sortSelect").addEventListener("change", (e) => {
        const [field, order] = e.target.value.split("-");
        state.filters.sortBy = field;
        state.filters.order = order;
        state.pagination.currentPage = 1;
        fetchMenuItems();
    });

    // Badge filter
    document.getElementById("badgeSelect").addEventListener("change", (e) => {
        state.filters.badge = e.target.value;
        state.pagination.currentPage = 1;
        fetchMenuItems();
    });

    // Price range slider
    const priceSlider = document.getElementById("priceRangeInput");
    const priceLabel = document.getElementById("priceMaxLabel");
    priceSlider.addEventListener("input", (e) => {
        priceLabel.textContent = formatRupiah(e.target.value);
    });
    priceSlider.addEventListener("change", (e) => {
        state.filters.maxPrice = e.target.value;
        state.pagination.currentPage = 1;
        fetchMenuItems();
    });

    // View toggle (Grid / List)
    const btnGrid = document.getElementById("btnGridView");
    const btnList = document.getElementById("btnListView");
    const menuGrid = document.getElementById("menuGrid");

    btnGrid.addEventListener("click", () => {
        btnGrid.classList.add("active");
        btnList.classList.remove("active");
        menuGrid.classList.remove("list-view");
    });
    btnList.addEventListener("click", () => {
        btnList.classList.add("active");
        btnGrid.classList.remove("active");
        menuGrid.classList.add("list-view");
    });

    // Carousel buttons
    document.getElementById("btnCarouselPrev").addEventListener("click", () => {
        document.getElementById("featuredCarousel").scrollBy({ left: -300, behavior: "smooth" });
    });
    document.getElementById("btnCarouselNext").addEventListener("click", () => {
        document.getElementById("featuredCarousel").scrollBy({ left: 300, behavior: "smooth" });
    });

    // Pagination buttons
    document.getElementById("btnPrevPage").addEventListener("click", () => {
        if (state.pagination.hasPrevPage) {
            goToPage(state.pagination.currentPage - 1);
        }
    });
    document.getElementById("btnNextPage").addEventListener("click", () => {
        if (state.pagination.hasNextPage) {
            goToPage(state.pagination.currentPage + 1);
        }
    });

    // Cart Drawer triggers
    document.getElementById("btnOpenCart").addEventListener("click", openCartDrawer);
    document.getElementById("btnCloseCart").addEventListener("click", closeCartDrawer);
    document.getElementById("cartBackdrop").addEventListener("click", closeCartDrawer);

    // Checkout
    document.getElementById("btnProceedCheckout").addEventListener("click", processOrderCheckout);

    // Track order
    document.getElementById("btnTrackOrder").addEventListener("click", openTrackOrderModal);
    document.getElementById("btnCloseTrackModal").addEventListener("click", () => closeModal("trackModal", "trackModalBackdrop"));
    document.getElementById("trackModalBackdrop").addEventListener("click", () => closeModal("trackModal", "trackModalBackdrop"));

    // Admin add menu
    document.getElementById("btnAdminAddMenu").addEventListener("click", () => openModal("adminModal", "adminModalBackdrop"));
    document.getElementById("btnCloseAdminModal").addEventListener("click", () => closeModal("adminModal", "adminModalBackdrop"));
    document.getElementById("btnCancelAdmin").addEventListener("click", () => closeModal("adminModal", "adminModalBackdrop"));
    document.getElementById("adminModalBackdrop").addEventListener("click", () => closeModal("adminModal", "adminModalBackdrop"));
    document.getElementById("adminMenuForm").addEventListener("submit", handleAdminCreateMenu);

    // Detail modal
    document.getElementById("btnCloseDetailModal").addEventListener("click", () => closeModal("detailModal", "detailModalBackdrop"));
    document.getElementById("detailModalBackdrop").addEventListener("click", () => closeModal("detailModal", "detailModalBackdrop"));

    // Receipt modal
    document.getElementById("btnCloseReceiptModal").addEventListener("click", () => closeModal("receiptModal", "receiptModalBackdrop"));
    document.getElementById("btnDoneReceipt").addEventListener("click", () => closeModal("receiptModal", "receiptModalBackdrop"));
    document.getElementById("receiptModalBackdrop").addEventListener("click", () => closeModal("receiptModal", "receiptModalBackdrop"));

    // Reservation Form
    document.getElementById("reservationForm").addEventListener("submit", (e) => {
        e.preventDefault();
        const name = document.getElementById("resName").value;
        const date = document.getElementById("resDate").value;
        const time = document.getElementById("resTime").value;
        const guests = document.getElementById("resGuests").value;

        showToast(`Permintaan reservasi atas nama ${name} (${date}, ${time} WIB) telah dikirim ke pihak kasir.`, "success");
        document.getElementById("reservationForm").reset();
    });

    document.getElementById("brandLogo").addEventListener("click", (e) => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
}

function focusSearchInput() {
    const input = document.getElementById("searchInput");
    input.focus();
    input.scrollIntoView({ behavior: "smooth", block: "center" });
}

function quickSearch(keyword) {
    const input = document.getElementById("searchInput");
    input.value = keyword;
    document.getElementById("btnClearSearch").style.display = "block";
    state.filters.search = keyword;
    state.pagination.currentPage = 1;
    fetchMenuItems();
    document.getElementById("catalogSection").scrollIntoView({ behavior: "smooth" });
}

function openCartDrawer() {
    document.getElementById("cartDrawer").classList.add("active");
    document.getElementById("cartBackdrop").classList.add("active");
    document.body.style.overflow = "hidden";
}

function closeCartDrawer() {
    document.getElementById("cartDrawer").classList.remove("active");
    document.getElementById("cartBackdrop").classList.remove("active");
    document.body.style.overflow = "auto";
}

function openModal(modalId, backdropId) {
    document.getElementById(modalId).classList.add("active");
    document.getElementById(backdropId).classList.add("active");
    document.body.style.overflow = "hidden";
}

function closeModal(modalId, backdropId) {
    document.getElementById(modalId).classList.remove("active");
    document.getElementById(backdropId).classList.remove("active");
    document.body.style.overflow = "auto";
}

function resetFilters() {
    state.filters.search = "";
    state.filters.category = "all";
    state.filters.maxPrice = 350000;
    state.filters.badge = "";
    state.pagination.currentPage = 1;

    document.getElementById("searchInput").value = "";
    document.getElementById("btnClearSearch").style.display = "none";
    document.getElementById("priceRangeInput").value = 350000;
    document.getElementById("priceMaxLabel").textContent = "Rp 350.000";
    document.getElementById("badgeSelect").value = "";

    const container = document.getElementById("categoryTabsContainer");
    if (container) {
        container.querySelectorAll(".cat-pill, .cat-tab-btn").forEach(p => p.classList.remove("active"));
        const allBtn = container.querySelector('[data-category="all"]');
        if (allBtn) allBtn.classList.add("active");
    }

    fetchMenuItems();
}

function filterByCategory(cat) {
    state.filters.category = cat;
    state.pagination.currentPage = 1;

    const container = document.getElementById("categoryTabsContainer");
    if (container) {
        container.querySelectorAll(".cat-pill, .cat-tab-btn").forEach(p => {
            if (p.getAttribute("data-category") === cat) p.classList.add("active");
            else p.classList.remove("active");
        });
    }

    fetchMenuItems();
}

// Toast Notifications
function showToast(message, type = "normal") {
    const container = document.getElementById("toastContainer");
    const toast = document.createElement("div");
    toast.className = "toast-msg";
    
    let icon = "🔔";
    if (type === "success") icon = "✅";
    if (type === "error") icon = "⚠️";

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transition = "opacity 0.2s ease";
        setTimeout(() => toast.remove(), 200);
    }, 2800);
}
