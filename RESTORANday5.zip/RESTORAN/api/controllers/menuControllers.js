const db = require("../config/database");

/**
 * GET /api/menu
 * Rich query params:
 * - page: number (default 1)
 * - limit: number (default 12)
 * - search: string
 * - kategori: string
 * - min_price: number
 * - max_price: number
 * - min_rating: number
 * - badge: string
 * - is_tersedia: 0 | 1
 * - sort_by: id | nama | harga | rating | total_terjual | created_at
 * - order: ASC | DESC
 * - all: boolean (if true, bypasses pagination)
 */
const getAllMenu = async (req, res) => {
    try {
        const {
            page = 1,
            limit = 12,
            search = "",
            kategori = "",
            min_price,
            max_price,
            min_rating,
            badge = "",
            is_tersedia,
            sort_by = "id",
            order = "DESC",
            all = false
        } = req.query;

        let conditions = [];
        let params = [];

        // Search in nama or deskripsi
        if (search && search.trim() !== "") {
            conditions.push("(nama LIKE ? OR deskripsi LIKE ? OR kategori LIKE ?)");
            const searchTerm = `%${search.trim()}%`;
            params.push(searchTerm, searchTerm, searchTerm);
        }

        // Filter by category
        if (kategori && kategori.trim() !== "" && kategori.toLowerCase() !== "all" && kategori.toLowerCase() !== "semua") {
            conditions.push("kategori = ?");
            params.push(kategori.trim());
        }

        // Filter by price
        if (min_price && !isNaN(min_price)) {
            conditions.push("harga >= ?");
            params.push(parseFloat(min_price));
        }
        if (max_price && !isNaN(max_price)) {
            conditions.push("harga <= ?");
            params.push(parseFloat(max_price));
        }

        // Filter by minimum rating
        if (min_rating && !isNaN(min_rating)) {
            conditions.push("rating >= ?");
            params.push(parseFloat(min_rating));
        }

        // Filter by badge
        if (badge && badge.trim() !== "") {
            conditions.push("badge LIKE ?");
            params.push(`%${badge.trim()}%`);
        }

        // Filter by availability
        if (is_tersedia !== undefined && is_tersedia !== "") {
            conditions.push("is_tersedia = ?");
            params.push(parseInt(is_tersedia, 10));
        }

        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

        // Allowed sort columns for SQL injection protection
        const allowedSortCols = ["id", "nama", "harga", "rating", "total_terjual", "created_at"];
        const sanitizedSort = allowedSortCols.includes(sort_by.toLowerCase()) ? sort_by.toLowerCase() : "id";
        const sanitizedOrder = order.toUpperCase() === "ASC" ? "ASC" : "DESC";

        // Count total matching items
        const countQuery = `SELECT COUNT(*) AS total FROM menu ${whereClause}`;
        const [countResult] = await db.query(countQuery, params);
        const totalItems = countResult[0].total;

        // If 'all' is requested, return without pagination (capped at 1000)
        if (String(all).toLowerCase() === "true") {
            const dataQuery = `SELECT * FROM menu ${whereClause} ORDER BY ${sanitizedSort} ${sanitizedOrder} LIMIT 1000`;
            const [rows] = await db.query(dataQuery, params);
            return res.json({
                success: true,
                total: totalItems,
                count: rows.length,
                data: rows
            });
        }

        const pageNum = Math.max(1, parseInt(page, 10) || 1);
        const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 12));
        const offset = (pageNum - 1) * limitNum;
        const totalPages = Math.ceil(totalItems / limitNum) || 1;

        const dataQuery = `
            SELECT * FROM menu 
            ${whereClause} 
            ORDER BY ${sanitizedSort} ${sanitizedOrder} 
            LIMIT ? OFFSET ?
        `;
        const queryParams = [...params, limitNum, offset];
        const [rows] = await db.query(dataQuery, queryParams);

        res.json({
            success: true,
            pagination: {
                totalItems,
                totalPages,
                currentPage: pageNum,
                limit: limitNum,
                hasNextPage: pageNum < totalPages,
                hasPrevPage: pageNum > 1
            },
            filters: {
                search: search || null,
                kategori: kategori || null,
                min_price: min_price || null,
                max_price: max_price || null,
                sort_by: sanitizedSort,
                order: sanitizedOrder
            },
            data: rows
        });
    } catch (error) {
        console.error("Error in getAllMenu:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengambil data menu",
            error: error.message
        });
    }
};

/**
 * GET /api/menu/categories
 * Returns all categories with item count and price summaries
 */
const getCategories = async (req, res) => {
    try {
        const query = `
            SELECT 
                kategori, 
                COUNT(*) AS total_items, 
                MIN(harga) AS min_harga, 
                MAX(harga) AS max_harga,
                AVG(rating) AS avg_rating
            FROM menu 
            GROUP BY kategori 
            ORDER BY kategori ASC
        `;
        const [rows] = await db.query(query);

        res.json({
            success: true,
            totalCategories: rows.length,
            data: rows
        });
    } catch (error) {
        console.error("Error in getCategories:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengambil daftar kategori",
            error: error.message
        });
    }
};

/**
 * GET /api/menu/stats
 * Restaurant statistics & overview
 */
const getMenuStats = async (req, res) => {
    try {
        const [totalStats] = await db.query(`
            SELECT 
                COUNT(*) AS total_menu,
                COUNT(DISTINCT kategori) AS total_kategori,
                MIN(harga) AS harga_terendah,
                MAX(harga) AS harga_tertinggi,
                ROUND(AVG(harga), 0) AS rata_rata_harga,
                ROUND(AVG(rating), 1) AS rata_rata_rating,
                SUM(total_terjual) AS total_penjualan_semua
            FROM menu
        `);

        // Top 5 Best Sellers
        const [bestSellers] = await db.query(`
            SELECT id, nama, kategori, harga, rating, total_terjual, gambar, badge 
            FROM menu 
            ORDER BY total_terjual DESC 
            LIMIT 5
        `);

        // Top 5 Highest Rated
        const [topRated] = await db.query(`
            SELECT id, nama, kategori, harga, rating, total_terjual, gambar, badge 
            FROM menu 
            ORDER BY rating DESC, total_terjual DESC 
            LIMIT 5
        `);

        // Chef recommendations / Featured
        const [featured] = await db.query(`
            SELECT id, nama, kategori, harga, rating, total_terjual, gambar, badge 
            FROM menu 
            WHERE badge IS NOT NULL 
            ORDER BY RAND() 
            LIMIT 6
        `);

        res.json({
            success: true,
            stats: totalStats[0],
            bestSellers,
            topRated,
            featured
        });
    } catch (error) {
        console.error("Error in getMenuStats:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengambil statistik menu",
            error: error.message
        });
    }
};

/**
 * GET /api/menu/:id
 * Get single menu item with related items from the same category
 */
const getMenuById = async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await db.query("SELECT * FROM menu WHERE id = ?", [id]);

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Menu tidak ditemukan"
            });
        }

        const menuItem = rows[0];

        // Fetch up to 4 related menu items from the same category
        const [related] = await db.query(
            "SELECT * FROM menu WHERE kategori = ? AND id != ? LIMIT 4",
            [menuItem.kategori, menuItem.id]
        );

        res.json({
            success: true,
            data: menuItem,
            relatedItems: related
        });
    } catch (error) {
        console.error("Error in getMenuById:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengambil detail menu",
            error: error.message
        });
    }
};

/**
 * POST /api/menu
 * Create a new menu item
 */
const createMenu = async (req, res) => {
    try {
        const {
            nama,
            deskripsi,
            kategori,
            harga,
            gambar,
            rating = 4.5,
            badge = null,
            is_tersedia = 1,
            kalori = null,
            estimasi_menit = 15
        } = req.body;

        if (!nama || !kategori || harga === undefined || harga === null) {
            return res.status(400).json({
                success: false,
                message: "Nama, kategori, dan harga wajib diisi"
            });
        }

        const numHarga = parseFloat(harga);
        if (isNaN(numHarga) || numHarga < 0) {
            return res.status(400).json({
                success: false,
                message: "Harga harus berupa angka valid >= 0"
            });
        }

        const [result] = await db.query(
            `INSERT INTO menu (
                nama, deskripsi, kategori, harga, rating, 
                badge, is_tersedia, kalori, estimasi_menit, gambar
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                nama.trim(),
                deskripsi ? deskripsi.trim() : null,
                kategori.trim(),
                numHarga,
                parseFloat(rating) || 4.5,
                badge || null,
                is_tersedia !== undefined ? parseInt(is_tersedia, 10) : 1,
                kalori ? parseInt(kalori, 10) : null,
                estimasi_menit ? parseInt(estimasi_menit, 10) : 15,
                gambar || null
            ]
        );

        const [newMenu] = await db.query("SELECT * FROM menu WHERE id = ?", [result.insertId]);

        res.status(201).json({
            success: true,
            message: "Menu berhasil ditambahkan",
            data: newMenu[0]
        });
    } catch (error) {
        console.error("Error in createMenu:", error);
        res.status(500).json({
            success: false,
            message: "Gagal menambahkan menu",
            error: error.message
        });
    }
};

/**
 * PUT /api/menu/:id
 * Update existing menu item
 */
const updateMenu = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            nama,
            deskripsi,
            kategori,
            harga,
            gambar,
            rating,
            badge,
            is_tersedia,
            kalori,
            estimasi_menit
        } = req.body;

        // Check if menu exists
        const [existing] = await db.query("SELECT * FROM menu WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Menu tidak ditemukan"
            });
        }

        const item = existing[0];
        const updatedNama = nama !== undefined ? nama.trim() : item.nama;
        const updatedDeskripsi = deskripsi !== undefined ? deskripsi : item.deskripsi;
        const updatedKategori = kategori !== undefined ? kategori.trim() : item.kategori;
        const updatedHarga = harga !== undefined ? parseFloat(harga) : item.harga;
        const updatedGambar = gambar !== undefined ? gambar : item.gambar;
        const updatedRating = rating !== undefined ? parseFloat(rating) : item.rating;
        const updatedBadge = badge !== undefined ? badge : item.badge;
        const updatedIsTersedia = is_tersedia !== undefined ? parseInt(is_tersedia, 10) : item.is_tersedia;
        const updatedKalori = kalori !== undefined ? parseInt(kalori, 10) : item.kalori;
        const updatedEstimasi = estimasi_menit !== undefined ? parseInt(estimasi_menit, 10) : item.estimasi_menit;

        await db.query(
            `UPDATE menu SET
                nama = ?,
                deskripsi = ?,
                kategori = ?,
                harga = ?,
                gambar = ?,
                rating = ?,
                badge = ?,
                is_tersedia = ?,
                kalori = ?,
                estimasi_menit = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?`,
            [
                updatedNama,
                updatedDeskripsi,
                updatedKategori,
                updatedHarga,
                updatedGambar,
                updatedRating,
                updatedBadge,
                updatedIsTersedia,
                updatedKalori,
                updatedEstimasi,
                id
            ]
        );

        const [updatedRows] = await db.query("SELECT * FROM menu WHERE id = ?", [id]);

        res.json({
            success: true,
            message: "Menu berhasil diperbarui",
            data: updatedRows[0]
        });
    } catch (error) {
        console.error("Error in updateMenu:", error);
        res.status(500).json({
            success: false,
            message: "Gagal memperbarui menu",
            error: error.message
        });
    }
};

/**
 * PATCH /api/menu/:id/toggle-status
 * Toggle menu availability (tersedia/habis)
 */
const toggleMenuStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const [existing] = await db.query("SELECT id, is_tersedia, nama FROM menu WHERE id = ?", [id]);
        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Menu tidak ditemukan"
            });
        }

        const newStatus = existing[0].is_tersedia === 1 ? 0 : 1;
        await db.query("UPDATE menu SET is_tersedia = ? WHERE id = ?", [newStatus, id]);

        res.json({
            success: true,
            message: `Status menu "${existing[0].nama}" berhasil diubah menjadi ${newStatus === 1 ? 'Tersedia' : 'Habis'}`,
            data: { id, is_tersedia: newStatus }
        });
    } catch (error) {
        console.error("Error in toggleMenuStatus:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengubah status ketersediaan menu",
            error: error.message
        });
    }
};

/**
 * DELETE /api/menu/:id
 * Delete menu item
 */
const deleteMenu = async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query("DELETE FROM menu WHERE id = ?", [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Menu tidak ditemukan"
            });
        }

        res.json({
            success: true,
            message: "Menu berhasil dihapus"
        });
    } catch (error) {
        console.error("Error in deleteMenu:", error);
        res.status(500).json({
            success: false,
            message: "Gagal menghapus menu",
            error: error.message
        });
    }
};

module.exports = {
    getAllMenu,
    getCategories,
    getMenuStats,
    getMenuById,
    createMenu,
    updateMenu,
    toggleMenuStatus,
    deleteMenu
};