const db = require("../config/database");

/**
 * Generate unique order number (e.g. ORD-20261001-XXXX)
 */
function generateOrderNumber() {
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    const randomHex = Math.floor(1000 + Math.random() * 9000);
    return `ORD-${dateStr}-${randomHex}`;
}

/**
 * POST /api/orders
 * Body:
 * {
 *   customer_name: "Yohanes",
 *   customer_phone: "08123456789",
 *   table_number: "Meja 05",
 *   payment_method: "QRIS",
 *   notes: "Jangan terlalu pedas",
 *   items: [
 *     { id: 1, nama: "...", harga: 50000, jumlah: 2, catatan: "kuah dipisah" }
 *   ]
 * }
 */
const createOrder = async (req, res) => {
    const connection = await db.getConnection();
    try {
        const {
            customer_name,
            customer_phone,
            table_number = "Take Away",
            payment_method = "QRIS",
            notes = "",
            items = []
        } = req.body;

        if (!customer_name || customer_name.trim() === "") {
            return res.status(400).json({
                success: false,
                message: "Nama pelanggan wajib diisi"
            });
        }

        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Keranjang belanja tidak boleh kosong"
            });
        }

        // Calculate financials
        let subtotal = 0;
        const validItems = [];

        for (const item of items) {
            const qty = parseInt(item.jumlah || item.quantity || 1, 10);
            const price = parseFloat(item.harga || 0);
            if (qty > 0 && price >= 0) {
                const itemTotal = price * qty;
                subtotal += itemTotal;
                validItems.push({
                    menu_id: item.id || null,
                    nama: item.nama || item.name || "Menu Makanan",
                    harga: price,
                    jumlah: qty,
                    subtotal: itemTotal,
                    catatan: item.catatan || ""
                });
            }
        }

        if (validItems.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Item pesanan tidak valid"
            });
        }

        const tax = Math.round(subtotal * 0.10); // 10% PB1 Restaurant Tax
        const serviceFee = Math.round(subtotal * 0.05); // 5% Service Charge
        const totalAmount = subtotal + tax + serviceFee;
        const orderNumber = generateOrderNumber();

        await connection.beginTransaction();

        // Insert into orders
        const [orderResult] = await connection.query(
            `INSERT INTO orders (
                order_number, customer_name, customer_phone, 
                table_number, subtotal, tax, service_fee, 
                total_amount, payment_method, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
            [
                orderNumber,
                customer_name.trim(),
                customer_phone ? customer_phone.trim() : null,
                table_number.trim(),
                subtotal,
                tax,
                serviceFee,
                totalAmount,
                payment_method,
                notes || null
            ]
        );

        const orderId = orderResult.insertId;

        // Insert order items
        const itemValues = validItems.map(item => [
            orderId,
            item.menu_id,
            item.nama,
            item.harga,
            item.jumlah,
            item.subtotal,
            item.catatan || null
        ]);

        await connection.query(
            `INSERT INTO order_items (
                order_id, menu_id, menu_nama, harga, jumlah, subtotal, catatan
            ) VALUES ?`,
            [itemValues]
        );

        // Increment total_terjual in menu table
        for (const it of validItems) {
            if (it.menu_id) {
                await connection.query(
                    "UPDATE menu SET total_terjual = total_terjual + ? WHERE id = ?",
                    [it.jumlah, it.menu_id]
                );
            }
        }

        await connection.commit();

        res.status(201).json({
            success: true,
            message: "Pesanan berhasil dibuat!",
            order: {
                id: orderId,
                order_number: orderNumber,
                customer_name,
                customer_phone,
                table_number,
                payment_method,
                status: "pending",
                subtotal,
                tax,
                service_fee: serviceFee,
                total_amount: totalAmount,
                items: validItems,
                created_at: new Date()
            }
        });
    } catch (error) {
        await connection.rollback();
        console.error("Error creating order:", error);
        res.status(500).json({
            success: false,
            message: "Gagal membuat pesanan",
            error: error.message
        });
    } finally {
        connection.release();
    }
};

/**
 * GET /api/orders
 * Get recent orders
 */
const getAllOrders = async (req, res) => {
    try {
        const { status, limit = 20, page = 1 } = req.query;
        let where = "";
        let params = [];

        if (status && status !== "all") {
            where = "WHERE status = ?";
            params.push(status);
        }

        const pageNum = Math.max(1, parseInt(page, 10) || 1);
        const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
        const offset = (pageNum - 1) * limitNum;

        const [orders] = await db.query(
            `SELECT * FROM orders ${where} ORDER BY id DESC LIMIT ? OFFSET ?`,
            [...params, limitNum, offset]
        );

        const [countResult] = await db.query(`SELECT COUNT(*) AS total FROM orders ${where}`, params);

        res.json({
            success: true,
            total: countResult[0].total,
            page: pageNum,
            limit: limitNum,
            data: orders
        });
    } catch (error) {
        console.error("Error in getAllOrders:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengambil daftar pesanan",
            error: error.message
        });
    }
};

/**
 * GET /api/orders/:id
 * Get single order with items
 */
const getOrderById = async (req, res) => {
    try {
        const { id } = req.params;
        const [orders] = await db.query("SELECT * FROM orders WHERE id = ? OR order_number = ?", [id, id]);

        if (orders.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Pesanan tidak ditemukan"
            });
        }

        const order = orders[0];
        const [items] = await db.query("SELECT * FROM order_items WHERE order_id = ?", [order.id]);

        res.json({
            success: true,
            data: {
                ...order,
                items
            }
        });
    } catch (error) {
        console.error("Error in getOrderById:", error);
        res.status(500).json({
            success: false,
            message: "Gagal mengambil data pesanan",
            error: error.message
        });
    }
};

/**
 * PATCH /api/orders/:id/status
 * Update status (pending, proses, selesai, dibatalkan)
 */
const updateOrderStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        const validStatuses = ["pending", "proses", "selesai", "dibatalkan"];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: `Status tidak valid. Pilihan: ${validStatuses.join(", ")}`
            });
        }

        const [result] = await db.query("UPDATE orders SET status = ? WHERE id = ?", [status, id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Pesanan tidak ditemukan"
            });
        }

        res.json({
            success: true,
            message: `Status pesanan #${id} berhasil diubah menjadi '${status}'`
        });
    } catch (error) {
        console.error("Error in updateOrderStatus:", error);
        res.status(500).json({
            success: false,
            message: "Gagal memperbarui status pesanan",
            error: error.message
        });
    }
};

module.exports = {
    createOrder,
    getAllOrders,
    getOrderById,
    updateOrderStatus
};
