const db = require("./database");

async function initDatabase() {
    try {
        console.log("Checking and initializing database tables...");

        // Ensure menu table has all rich columns
        const alterQueries = [
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS deskripsi TEXT AFTER nama",
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS rating DECIMAL(2,1) DEFAULT 4.5 AFTER harga",
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS total_terjual INT DEFAULT 0 AFTER rating",
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS badge VARCHAR(50) DEFAULT NULL AFTER total_terjual",
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS is_tersedia TINYINT(1) DEFAULT 1 AFTER badge",
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS kalori INT DEFAULT NULL AFTER is_tersedia",
            "ALTER TABLE menu ADD COLUMN IF NOT EXISTS estimasi_menit INT DEFAULT 15 AFTER kalori"
        ];

        for (const query of alterQueries) {
            try {
                await db.query(query);
            } catch (e) {
                // Ignore if column already exists or syntax differences
            }
        }

        // Create orders table
        await db.query(`
            CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_number VARCHAR(50) NOT NULL UNIQUE,
                customer_name VARCHAR(100) NOT NULL,
                customer_phone VARCHAR(50),
                table_number VARCHAR(20) DEFAULT 'Meja 1',
                subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
                tax DECIMAL(12,2) DEFAULT 0,
                service_fee DECIMAL(12,2) DEFAULT 0,
                total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
                payment_method VARCHAR(50) DEFAULT 'QRIS',
                status ENUM('pending', 'proses', 'selesai', 'dibatalkan') DEFAULT 'pending',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB;
        `);

        // Create order_items table
        await db.query(`
            CREATE TABLE IF NOT EXISTS order_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                menu_id INT,
                menu_nama VARCHAR(150) NOT NULL,
                harga DECIMAL(12,2) NOT NULL,
                jumlah INT NOT NULL DEFAULT 1,
                subtotal DECIMAL(12,2) NOT NULL,
                catatan VARCHAR(255),
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
            ) ENGINE=InnoDB;
        `);

        console.log("Database initialized successfully!");
    } catch (error) {
        console.error("Database initialization failed:", error.message);
    }
}

module.exports = initDatabase;

if (require.main === module) {
    initDatabase().then(() => process.exit(0)).catch(e => {
        console.error(e);
        process.exit(1);
    });
}
