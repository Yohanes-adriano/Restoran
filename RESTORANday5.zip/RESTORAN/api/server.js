const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const initDatabase = require("./config/initDb");
const menuRoutes = require("./routes/menuRoutes");
const orderRoutes = require("./routes/orderRoutes");

const app = express();

// Middlewares
app.use(cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve Frontend Static Files
app.use(express.static(path.join(__dirname, "../frontend")));

// Simple request logger
app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () => {
        const duration = Date.now() - start;
        console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`);
    });
    next();
});

// API Info Endpoint
app.get("/api", (req, res) => {
    res.json({
        success: true,
        message: "Selamat Datang di API Adriano Resto",
        version: "2.0.0",
        author: "Adriano Resto Team",
        endpoints: {
            menu: {
                getAll: "GET /api/menu?page=1&limit=12&kategori=&search=&sort_by=id&order=DESC",
                getCategories: "GET /api/menu/categories",
                getStats: "GET /api/menu/stats",
                getDetail: "GET /api/menu/:id",
                create: "POST /api/menu",
                update: "PUT /api/menu/:id",
                toggleStatus: "PATCH /api/menu/:id/toggle-status",
                delete: "DELETE /api/menu/:id"
            },
            orders: {
                createOrder: "POST /api/orders",
                getAllOrders: "GET /api/orders?status=pending&page=1&limit=20",
                getOrderDetail: "GET /api/orders/:id",
                updateStatus: "PATCH /api/orders/:id/status"
            }
        }
    });
});

// Mount Routes
app.use("/api/menu", menuRoutes);
app.use("/api/orders", orderRoutes);

// 404 Route Handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: `Endpoint ${req.method} ${req.originalUrl} tidak ditemukan`
    });
});

// Global Error Handler
app.use((err, req, res, next) => {
    console.error("Unhandled Error:", err);
    res.status(500).json({
        success: false,
        message: "Terjadi kesalahan internal pada server",
        error: err.message
    });
});

// Server Initialization
const PORT = process.env.PORT || 3000;

async function startServer() {
    try {
        await initDatabase();
        app.listen(PORT, () => {
            console.log(`=================================================`);
            console.log(`🚀 Server Adriano Resto Berjalan di http://localhost:${PORT}`);
            console.log(`📖 Endpoint Menu:    http://localhost:${PORT}/api/menu`);
            console.log(`📊 Endpoint Stats:   http://localhost:${PORT}/api/menu/stats`);
            console.log(`🏷️ Endpoint Kategori: http://localhost:${PORT}/api/menu/categories`);
            console.log(`🛒 Endpoint Orders:  http://localhost:${PORT}/api/orders`);
            console.log(`=================================================`);
        });
    } catch (err) {
        console.error("Gagal memulai server:", err);
        process.exit(1);
    }
}

startServer();