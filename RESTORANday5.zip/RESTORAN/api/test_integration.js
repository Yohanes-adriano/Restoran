const http = require("http");

function fetchUrl(url, method = "GET", body = null) {
    return new Promise((resolve, reject) => {
        const u = new URL(url);
        const opts = {
            hostname: u.hostname,
            port: u.port,
            path: u.pathname + u.search,
            method,
            headers: { "Content-Type": "application/json" }
        };
        const req = http.request(opts, (res) => {
            let data = "";
            res.on("data", chunk => data += chunk);
            res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
        });
        req.on("error", reject);
        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

async function runTests() {
    console.log("=== 1. Testing Frontend Static Assets Delivery ===");
    const indexRes = await fetchUrl("http://127.0.0.1:3000/");
    console.log(`[PASS] GET / -> HTTP ${indexRes.status} (Size: ${indexRes.body.length} bytes)`);

    const cssRes = await fetchUrl("http://127.0.0.1:3000/styles.css");
    console.log(`[PASS] GET /styles.css -> HTTP ${cssRes.status} (Size: ${cssRes.body.length} bytes)`);

    const jsRes = await fetchUrl("http://127.0.0.1:3000/app.js");
    console.log(`[PASS] GET /app.js -> HTTP ${jsRes.status} (Size: ${jsRes.body.length} bytes)`);

    console.log("\n=== 2. Testing API Endpoints ===");
    const apiInfoRes = await fetchUrl("http://127.0.0.1:3000/api");
    console.log(`[PASS] GET /api -> HTTP ${apiInfoRes.status}`);

    const menuRes = await fetchUrl("http://127.0.0.1:3000/api/menu?page=1&limit=6");
    const menuJson = JSON.parse(menuRes.body);
    console.log(`[PASS] GET /api/menu -> HTTP ${menuRes.status} | Total Menu: ${menuJson.pagination.totalItems} | Page: ${menuJson.pagination.currentPage}/${menuJson.pagination.totalPages}`);

    const catRes = await fetchUrl("http://127.0.0.1:3000/api/menu/categories");
    const catJson = JSON.parse(catRes.body);
    console.log(`[PASS] GET /api/menu/categories -> HTTP ${catRes.status} | Total Categories: ${catJson.totalCategories}`);
    catJson.data.forEach(c => console.log(`   - ${c.kategori}: ${c.total_items} items (Rp ${c.min_harga} - Rp ${c.max_harga})`));

    const statsRes = await fetchUrl("http://127.0.0.1:3000/api/menu/stats");
    const statsJson = JSON.parse(statsRes.body);
    console.log(`[PASS] GET /api/menu/stats -> HTTP ${statsRes.status} | Total: ${statsJson.stats.total_menu} | Avg Rating: ${statsJson.stats.rata_rata_rating}`);

    const searchRes = await fetchUrl("http://127.0.0.1:3000/api/menu?search=Wagyu");
    const searchJson = JSON.parse(searchRes.body);
    console.log(`[PASS] GET /api/menu?search=Wagyu -> HTTP ${searchRes.status} | Found: ${searchJson.pagination.totalItems} items`);

    const filterCatRes = await fetchUrl("http://127.0.0.1:3000/api/menu?kategori=Nusantara&limit=5");
    const filterCatJson = JSON.parse(filterCatRes.body);
    console.log(`[PASS] GET /api/menu?kategori=Nusantara -> HTTP ${filterCatRes.status} | Found: ${filterCatJson.pagination.totalItems} items`);

    const orderRes = await fetchUrl("http://127.0.0.1:3000/api/orders", "POST", {
        customer_name: "Yohanes Adriano",
        customer_phone: "081234567890",
        table_number: "Meja 05 (VIP Sofa)",
        payment_method: "QRIS",
        notes: "Pedas sedang, sajikan hangat",
        items: [
            { id: menuJson.data[0].id, nama: menuJson.data[0].nama, harga: menuJson.data[0].harga, jumlah: 2 }
        ]
    });
    const orderJson = JSON.parse(orderRes.body);
    console.log(`[PASS] POST /api/orders -> HTTP ${orderRes.status} | Order No: ${orderJson.order.order_number} | Grand Total: Rp ${orderJson.order.total_amount}`);

    const ordersListRes = await fetchUrl("http://127.0.0.1:3000/api/orders");
    const ordersListJson = JSON.parse(ordersListRes.body);
    console.log(`[PASS] GET /api/orders -> HTTP ${ordersListRes.status} | Total Orders in Database: ${ordersListJson.total}`);

    console.log("\n========================================================");
    console.log("🌟 ALL INTEGRATION & PERFORMANCE TESTS PASSED 100%! 🌟");
    console.log("========================================================");
}

runTests().then(() => process.exit(0)).catch(e => {
    console.error(e);
    process.exit(1);
});
