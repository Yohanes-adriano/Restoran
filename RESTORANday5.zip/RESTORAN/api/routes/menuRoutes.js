const express = require("express");
const router = express.Router();

const {
    getAllMenu,
    getCategories,
    getMenuStats,
    getMenuById,
    createMenu,
    updateMenu,
    toggleMenuStatus,
    deleteMenu
} = require("../controllers/menuControllers");

// Special route endpoints (before :id)
router.get("/categories", getCategories);
router.get("/stats", getMenuStats);

// Main menu endpoints
router.get("/", getAllMenu);
router.get("/:id", getMenuById);
router.post("/", createMenu);
router.put("/:id", updateMenu);
router.patch("/:id/toggle-status", toggleMenuStatus);
router.delete("/:id", deleteMenu);

module.exports = router;