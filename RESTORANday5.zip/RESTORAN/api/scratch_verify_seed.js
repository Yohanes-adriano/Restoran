const https = require('https');

// The curated dish image mapping
const dishImageMap = {
    // Rice & Nasi
    nasi_goreng: [
        "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
    ],
    nasi_campur: [
        "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
    ],
    // Satay
    satay: [
        "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1751212352288-d5811798804c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80"
    ],
    // Poultry: Ayam & Bebek
    chicken_fried: [
        "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1587593810167-a84920ea0781?auto=format&fit=crop&w=600&q=80"
    ],
    chicken_grilled: [
        "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80"
    ],
    // Braised & Stewed Beef: Rendang, Rawon, Empal, Brisket
    beef_stew: [
        "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80"
    ],
    // Traditional Indonesian Vegetables & Tofu
    indo_salad: [
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80"
    ],
    // Steaks & Ribs
    steak: [
        "https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80"
    ],
    ribs: [
        "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=600&q=80"
    ],
    // Burgers & Sandwiches
    burger: [
        "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80"
    ],
    // Pizza
    pizza: [
        "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=600&q=80"
    ],
    // Pasta & Lasagna
    pasta: [
        "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546549032-9571cd6b27df?auto=format&fit=crop&w=600&q=80"
    ],
    lasagna: [
        "https://images.unsplash.com/photo-1574894709920-11b28e7367e3?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80"
    ],
    // Ramen
    ramen: [
        "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1591814468924-caf88d1232e1?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1617093727343-374698b1b08d?auto=format&fit=crop&w=600&q=80"
    ],
    // Asian Stir Fried Noodles (Mie Aceh, Pad Thai, Kwetiau)
    noodles: [
        "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=600&q=80"
    ],
    // Sushi
    sushi: [
        "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&w=600&q=80"
    ],
    // Dimsum & Dumplings
    dimsum: [
        "https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1498654896293-37aacf113fd9?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80"
    ],
    // Donburi & Japanese Rice
    donburi: [
        "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Crab & Lobster
    crab_lobster: [
        "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Shrimp / Prawn
    shrimp: [
        "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Fish / Salmon
    fish: [
        "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Calamari / Squid / Octopus
    calamari: [
        "https://images.unsplash.com/photo-1608039829572-78524f79c4c7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Clams & Mussels
    clams: [
        "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Tiramisu
    tiramisu: [
        "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Chocolate Cake / Lava Cake / Brownie
    chocolate_cake: [
        "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Cheesecake & Panna Cotta
    cheesecake: [
        "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559203206-dc1d3857ec33?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Waffle & Pancake
    waffle: [
        "https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1562376552-0d160a2f238d?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Croissant & Pastry
    croissant: [
        "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Traditional / Gelato
    sweet_treats: [
        "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Hot Coffee & Latte
    hot_coffee: [
        "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Iced Coffee / Kopi Susu
    iced_coffee: [
        "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Tea & Matcha
    tea_matcha: [
        "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1497636577773-f1231844b336?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Juices & Mocktails
    juices_mocktails: [
        "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=600&q=80"
    ],
    // Snacks: French Fries & Potato Wedges
    fries: [
        "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&w=600&q=80"
    ],
    // Snacks: Wings & Finger Foods
    fried_snacks: [
        "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1608039829572-78524f79c4c7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=600&q=80"
    ],
    // Snacks: Nachos
    nachos: [
        "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=600&q=80"
    ],
    // Salad & Healthy Bowls
    salad: [
        "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546793665-c74683f339c1?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80"
    ],
    // Soups & Hotpots
    soup: [
        "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=600&q=80"
    ]
};

// Function that resolves a base dish name to the exact matching image pool
function resolveDishImagePool(baseName, category) {
    const b = baseName.toLowerCase();

    // 1. Nusantara & Specific Dishes
    if (b.includes('nasi goreng')) return dishImageMap.nasi_goreng;
    if (b.includes('nasi liwet') || b.includes('nasi uduk') || b.includes('nasi kuning') || b.includes('nasi hainan')) return dishImageMap.nasi_campur;
    if (b.includes('sate')) return dishImageMap.satay;
    if (b.includes('ayam bakar') || b.includes('bebek bakar') || b.includes('taliwang') || b.includes('betutu') || b.includes('teriyaki')) return dishImageMap.chicken_grilled;
    if (b.includes('ayam goreng') || b.includes('bebek goreng') || b.includes('schnitzel') || b.includes('katsu')) return dishImageMap.chicken_fried;
    if (b.includes('rendang') || b.includes('rawon') || b.includes('empal') || b.includes('selat solo') || b.includes('brisket') || b.includes('pulled beef') || b.includes('mongolian')) return dishImageMap.beef_stew;
    if (b.includes('soto') || b.includes('buntut') || b.includes('iga sapi') || b.includes('sop') || b.includes('sup') || b.includes('chowder') || b.includes('hotpot') || b.includes('sukiyaki') || b.includes('nabe') || b.includes('tom yum')) return dishImageMap.soup;
    if (b.includes('gado-gado') || b.includes('karedok') || b.includes('tahu telur') || b.includes('gudeg')) return dishImageMap.indo_salad;
    if (b.includes('mie') || b.includes('kwetiau') || b.includes('pad thai')) return dishImageMap.noodles;

    // 2. Western & Grill
    if (b.includes('steak') || b.includes('wagyu') || b.includes('sirloin') || b.includes('ribeye') || b.includes('tenderloin') || b.includes('t-bone') || b.includes('lamb chop') || b.includes('surf & turf') || b.includes('wellington')) return dishImageMap.steak;
    if (b.includes('ribs') || b.includes('bratwurst')) return dishImageMap.ribs;
    if (b.includes('burger') || b.includes('sandwich') || b.includes('philly cheese')) return dishImageMap.burger;

    // 3. Pasta & Pizza
    if (b.includes('pizza') || b.includes('calzone')) return dishImageMap.pizza;
    if (b.includes('lasagna')) return dishImageMap.lasagna;
    if (b.includes('spaghetti') || b.includes('fettuccine') || b.includes('penne') || b.includes('ravioli') || b.includes('tagliatelle') || b.includes('fusilli') || b.includes('macaroni') || b.includes('gnocchi') || b.includes('pasta')) return dishImageMap.pasta;

    // 4. Asian & Japanese
    if (b.includes('ramen')) return dishImageMap.ramen;
    if (b.includes('sushi') || b.includes('roll') || b.includes('nigiri')) return dishImageMap.sushi;
    if (b.includes('dimsum') || b.includes('hakau') || b.includes('siomay')) return dishImageMap.dimsum;
    if (b.includes('donburi') || b.includes('rice bowl') || b.includes('gyu don') || b.includes('tempura') || b.includes('kung pao')) return dishImageMap.donburi;

    // 5. Seafood
    if (b.includes('kepiting') || b.includes('lobster')) return dishImageMap.crab_lobster;
    if (b.includes('udang')) return dishImageMap.shrimp;
    if (b.includes('ikan') || b.includes('salmon') || b.includes('kakap') || b.includes('kerapu') || b.includes('bawal') || b.includes('baronang') || b.includes('gurame') || b.includes('nila') || b.includes('patin') || b.includes('fish & chips')) return dishImageMap.fish;
    if (b.includes('cumi') || b.includes('calamari') || b.includes('gurita') || b.includes('octopus')) return dishImageMap.calamari;
    if (b.includes('kerang') || b.includes('seafood platter')) return dishImageMap.clams;

    // 6. Dessert & Pastry
    if (b.includes('tiramisu')) return dishImageMap.tiramisu;
    if (b.includes('lava cake') || b.includes('brownies') || b.includes('choco')) return dishImageMap.chocolate_cake;
    if (b.includes('cheesecake') || b.includes('panna cotta') || b.includes('creme brulee')) return dishImageMap.cheesecake;
    if (b.includes('waffle') || b.includes('pancake') || b.includes('churros') || b.includes('poffertjes')) return dishImageMap.waffle;
    if (b.includes('croissant') || b.includes('pie')) return dishImageMap.croissant;
    if (b.includes('cendol') || b.includes('es campur') || b.includes('pisang') || b.includes('martabak') || b.includes('mochi') || b.includes('gelato')) return dishImageMap.sweet_treats;

    // 7. Beverages
    if (b.includes('kopi susu') || b.includes('macchiato') || b.includes('americano') || b.includes('espresso tonic') || b.includes('avocado coffee')) return dishImageMap.iced_coffee;
    if (b.includes('latte') || b.includes('cappuccino')) return dishImageMap.hot_coffee;
    if (b.includes('matcha') || b.includes('teh') || b.includes('tea') || b.includes('taro')) return dishImageMap.tea_matcha;
    if (b.includes('jus') || b.includes('mocktail') || b.includes('mojito') || b.includes('smoothie')) return dishImageMap.juices_mocktails;

    // 8. Snacks
    if (b.includes('fries') || b.includes('wedges')) return dishImageMap.fries;
    if (b.includes('nachos')) return dishImageMap.nachos;
    if (b.includes('wings') || b.includes('tahu') || b.includes('risoles') || b.includes('bitterballen') || b.includes('onion') || b.includes('spring roll') || b.includes('mozzarella') || b.includes('singkong') || b.includes('bala-bala')) return dishImageMap.fried_snacks;

    // 9. Healthy & Salad
    if (category === 'Healthy & Salad' || b.includes('salad') || b.includes('bowl')) return dishImageMap.salad;

    // Fallbacks based on category
    if (category === 'Seafood') return dishImageMap.fish;
    if (category === 'Beverages & Coffee') return dishImageMap.iced_coffee;
    if (category === 'Dessert & Pastry') return dishImageMap.sweet_treats;
    if (category === 'Pasta & Pizza') return dishImageMap.pasta;
    if (category === 'Western & Grill') return dishImageMap.steak;
    if (category === 'Asian & Japanese') return dishImageMap.donburi;
    if (category === 'Soup & Hotpot') return dishImageMap.soup;
    if (category === 'Snacks & Appetizers') return dishImageMap.fried_snacks;

    return dishImageMap.nasi_goreng;
}

module.exports = { dishImageMap, resolveDishImagePool };
