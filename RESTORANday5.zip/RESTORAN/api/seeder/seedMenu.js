const db = require("../config/database");

// Curated high quality food photography image pools matching specific dish types accurately
const dishImageMap = {
    // Rice & Nasi
    nasi_goreng: [
        "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
    ],
    nasi_campur: [
        "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80"
    ],
    // Satay (Indonesian Sate Ayam, Kambing, Maranggi)
    satay: [
        "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1751212352288-d5811798804c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80"
    ],
    // Poultry: Ayam & Bebek
    chicken_fried: [
        "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1587593810167-a84920ea0781?auto=format&fit=crop&w=600&q=80"
    ],
    chicken_grilled: [
        "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80"
    ],
    // Braised & Stewed Beef: Rendang, Rawon, Empal, Brisket
    beef_stew: [
        "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80"
    ],
    // Traditional Indonesian Vegetables & Tofu
    indo_salad: [
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80"
    ],
    // Steaks & Ribs
    steak: [
        "https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80"
    ],
    ribs: [
        "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=600&q=80"
    ],
    // Burgers & Sandwiches
    burger: [
        "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80"
    ],
    // Pizza & Calzone
    pizza: [
        "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=600&q=80"
    ],
    // Pasta & Lasagna
    pasta: [
        "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546549032-9571cd6b27df?auto=format&fit=crop&w=600&q=80"
    ],
    lasagna: [
        "https://images.unsplash.com/photo-1574894709920-11b28e7367e3?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80"
    ],
    // Ramen
    ramen: [
        "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1591814468924-caf88d1232e1?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1617093727343-374698b1b08d?auto=format&fit=crop&w=600&q=80"
    ],
    // Asian Stir Fried Noodles (Mie Aceh, Pad Thai, Kwetiau)
    noodles: [
        "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=600&q=80"
    ],
    // Sushi
    sushi: [
        "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&w=600&q=80"
    ],
    // Dimsum & Dumplings
    dimsum: [
        "https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1498654896293-37aacf113fd9?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80"
    ],
    // Donburi & Japanese Rice Bowls
    donburi: [
        "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Crab & Lobster
    crab_lobster: [
        "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Shrimp / Prawn
    shrimp: [
        "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Fish / Salmon
    fish: [
        "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Calamari / Squid / Octopus
    calamari: [
        "https://images.unsplash.com/photo-1608039829572-78524f79c4c7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=600&q=80"
    ],
    // Seafood: Clams & Mussels
    clams: [
        "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Tiramisu
    tiramisu: [
        "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Chocolate Cake / Lava Cake / Brownie
    chocolate_cake: [
        "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Cheesecake & Panna Cotta
    cheesecake: [
        "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1559203206-dc1d3857ec33?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Waffle & Pancake
    waffle: [
        "https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1562376552-0d160a2f238d?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Croissant & Pastry
    croissant: [
        "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80"
    ],
    // Desserts: Traditional / Gelato
    sweet_treats: [
        "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Hot Coffee & Latte
    hot_coffee: [
        "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Iced Coffee / Kopi Susu
    iced_coffee: [
        "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Tea & Matcha
    tea_matcha: [
        "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1497636577773-f1231844b336?auto=format&fit=crop&w=600&q=80"
    ],
    // Beverages: Juices & Mocktails
    juices_mocktails: [
        "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=600&q=80"
    ],
    // Snacks: French Fries & Potato Wedges
    fries: [
        "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&w=600&q=80"
    ],
    // Snacks: Wings & Finger Foods
    fried_snacks: [
        "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1608039829572-78524f79c4c7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=600&q=80"
    ],
    // Snacks: Nachos
    nachos: [
        "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=600&q=80"
    ],
    // Salad & Healthy Bowls
    salad: [
        "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546793665-c74683f339c1?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80"
    ],
    // Soups & Hotpots
    soup: [
        "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=600&q=80"
    ]
};

// Function that precisely resolves a base dish name to its matching food photography pool
function resolveDishImagePool(baseName, category) {
    const b = baseName.toLowerCase();

    // 1. Pizza & Calzone
    if (b.includes('pizza') || b.includes('calzone')) return dishImageMap.pizza;

    // 2. Burgers & Sandwiches
    if (b.includes('burger') || b.includes('sandwich') || b.includes('philly cheese')) return dishImageMap.burger;

    // 3. Pasta & Lasagna
    if (b.includes('lasagna')) return dishImageMap.lasagna;
    if (b.includes('spaghetti') || b.includes('fettuccine') || b.includes('penne') || b.includes('ravioli') || 
        b.includes('tagliatelle') || b.includes('fusilli') || b.includes('macaroni') || b.includes('gnocchi') || 
        b.includes('carbonara') || b.includes('bolognese') || b.includes('aglio olio') || b.includes('alfredo') || 
        b.includes('pescatore') || b.includes('pasta')) return dishImageMap.pasta;

    // 4. Ramen
    if (b.includes('ramen')) return dishImageMap.ramen;

    // 5. Dimsum & Dumplings
    if (b.includes('dimsum') || b.includes('hakau') || b.includes('siomay') || b.includes('spring roll')) return dishImageMap.dimsum;

    // 6. Sushi
    if ((b.includes('sushi') || b.includes('nigiri') || b.includes('aburi') || b.includes('dragon roll')) && 
        !b.includes('martabak') && !b.includes('spring roll')) return dishImageMap.sushi;

    // 7. Satay (Indonesian Sate)
    if (b.includes('sate') || b.includes('satay')) return dishImageMap.satay;

    // 8. Rice dishes (Nasi Goreng, Liwet, Uduk, Kuning, Hainan)
    if (b.includes('nasi goreng')) return dishImageMap.nasi_goreng;
    if (b.includes('nasi liwet') || b.includes('nasi uduk') || b.includes('nasi kuning') || b.includes('nasi hainan') || b.includes('nasi ')) return dishImageMap.nasi_campur;

    // 9. Healthy & Salads
    if (category === 'Healthy & Salad' || b.includes('salad') || b.includes('superfood bowl') || b.includes('acai') || b.includes('açai')) return dishImageMap.salad;

    // 10. Soups & Hotpots
    if (category === 'Soup & Hotpot' || b.includes('sop ') || b.includes('soto ') || b.includes('buntut') || 
        b.includes('iga sapi') || b.includes('kaki sapi') || b.includes('soup') || b.includes('sup ') || 
        b.includes('chowder') || b.includes('hotpot') || b.includes('sukiyaki') || b.includes('nabe') || b.includes('tom yum')) return dishImageMap.soup;

    // 11. Seafood specifics
    if (b.includes('kepiting') || b.includes('lobster')) return dishImageMap.crab_lobster;
    if (b.includes('udang') || b.includes('prawn') || b.includes('shrimp')) return dishImageMap.shrimp;
    if (b.includes('cumi') || b.includes('calamari') || b.includes('gurita') || b.includes('octopus')) return dishImageMap.calamari;
    if (b.includes('kerang') || b.includes('seafood platter')) return dishImageMap.clams;
    if (b.includes('salmon') || b.includes('ikan') || b.includes('gurame') || b.includes('nila') || 
        b.includes('patin') || b.includes('kakap') || b.includes('kerapu') || b.includes('bawal') || 
        b.includes('baronang') || b.includes('fish & chips')) return dishImageMap.fish;

    // 12. Steaks & Ribs
    if (b.includes('ribs') || b.includes('bratwurst')) return dishImageMap.ribs;
    if (b.includes('steak') || b.includes('wagyu') || b.includes('sirloin') || b.includes('ribeye') || 
        b.includes('tenderloin') || b.includes('t-bone') || b.includes('lamb chop') || b.includes('surf & turf') || 
        b.includes('wellington')) return dishImageMap.steak;

    // 13. Poultry
    if (b.includes('ayam goreng') || b.includes('bebek goreng') || b.includes('schnitzel') || b.includes('katsu') || b.includes('wings')) return dishImageMap.chicken_fried;
    if (b.includes('ayam bakar') || b.includes('bebek bakar') || b.includes('taliwang') || b.includes('betutu') || 
        b.includes('chicken breast') || b.includes('chicken teriyaki') || b.includes('grilled chicken')) return dishImageMap.chicken_grilled;

    // 14. Beef stews (Rendang, Rawon, Empal, Brisket)
    if (b.includes('rendang') || b.includes('rawon') || b.includes('empal') || b.includes('selat solo') || 
        b.includes('brisket') || b.includes('pulled') || b.includes('mongolian')) return dishImageMap.beef_stew;

    // 15. Asian bowls & noodles
    if (b.includes('pad thai')) return dishImageMap.noodles;
    if (b.includes('donburi') || b.includes('gyu don') || b.includes('tempura') || b.includes('kung pao')) return dishImageMap.donburi;
    if (b.includes('mie') || b.includes('kwetiau')) return dishImageMap.noodles;

    // 16. Indonesian vegetables & tofu
    if (b.includes('gado-gado') || b.includes('karedok') || b.includes('tahu telur') || b.includes('gudeg')) return dishImageMap.indo_salad;

    // 17. Desserts
    if (b.includes('tiramisu')) return dishImageMap.tiramisu;
    if (b.includes('lava cake') || b.includes('brownie') || b.includes('choco')) return dishImageMap.chocolate_cake;
    if (b.includes('cheesecake') || b.includes('panna cotta') || b.includes('creme brulee')) return dishImageMap.cheesecake;
    if (b.includes('waffle') || b.includes('pancake') || b.includes('churros') || b.includes('poffertjes')) return dishImageMap.waffle;
    if (b.includes('croissant') || b.includes('pie')) return dishImageMap.croissant;
    if (b.includes('cendol') || b.includes('es campur') || b.includes('pisang') || b.includes('martabak') || 
        b.includes('mochi') || b.includes('gelato')) return dishImageMap.sweet_treats;

    // 18. Beverages
    if (b.includes('matcha')) return dishImageMap.tea_matcha;
    if (b.includes('latte') || b.includes('cappuccino')) return dishImageMap.hot_coffee;
    if (b.includes('kopi') || b.includes('macchiato') || b.includes('americano') || b.includes('espresso') || b.includes('coffee')) return dishImageMap.iced_coffee;
    if (b.includes('teh') || b.includes('tea') || b.includes('taro')) return dishImageMap.tea_matcha;
    if (b.includes('jus') || b.includes('mocktail') || b.includes('mojito') || b.includes('smoothie')) return dishImageMap.juices_mocktails;

    // 19. Snacks
    if (b.includes('fries') || b.includes('wedges')) return dishImageMap.fries;
    if (b.includes('nachos')) return dishImageMap.nachos;
    if (category === 'Snacks & Appetizers') return dishImageMap.fried_snacks;

    // Fallbacks based on category
    if (category === 'Seafood') return dishImageMap.fish;
    if (category === 'Beverages & Coffee') return dishImageMap.iced_coffee;
    if (category === 'Dessert & Pastry') return dishImageMap.sweet_treats;
    if (category === 'Pasta & Pizza') return dishImageMap.pasta;
    if (category === 'Western & Grill') return dishImageMap.steak;
    if (category === 'Asian & Japanese') return dishImageMap.donburi;
    if (category === 'Soup & Hotpot') return dishImageMap.soup;
    if (category === 'Snacks & Appetizers') return dishImageMap.fried_snacks;

    return dishImageMap.nasi_goreng;
}

// Category templates with base dishes, cooking styles/flavors, and description blueprints
const categoryTemplates = {
    "Nusantara": {
        bases: [
            "Nasi Goreng", "Ayam Bakar", "Ayam Goreng", "Bebek Goreng", "Bebek Bakar",
            "Sate Ayam", "Sate Kambing", "Sate Maranggi", "Rendang Sapi", "Rawon Daging",
            "Sop Buntut", "Soto Betawi", "Soto Ayam Lamongan", "Gudeg Komplit", "Ikan Gurame Bakar",
            "Ikan Nila Terbang", "Ayam Taliwang", "Ayam Betutu", "Gado-Gado", "Tahu Telur",
            "Nasi Liwet", "Nasi Uduk", "Nasi Kuning", "Ikan Patin Asam Pedas", "Gulai Kepala Kakap",
            "Empal Gentong", "Selat Solo", "Karedok Sunda", "Mie Aceh", "Mie Goreng Jawa"
        ],
        styles: [
            "Spesial Sambal Matah", "Bumbu Jimbaran Khas Bali", "Rica-Rica Pedas Manado", "Bumbu Hitam Madura",
            "Saus Telur Asin Gurih", "Sambal Ijo Padang", "Bumbu Rujak Keraton", "Gongso Pedas Manis",
            "Serundeng Lengkuas", "Bumbu Rempah Nusantara", "Lada Hitam Melimpah", "Sambal Roa Khas Manado",
            "Kuah Santan Gurih", "Bumbu Asap Tradisional", "Penyet Sambal Korek Super Pedas"
        ],
        desc: "Hidangan otentik nusantara dipadukan dengan rempah-rempah pilihan yang meresap sempurna hingga ke serat terdalam, disajikan segar dengan lalapan dan sambal khas.",
        priceRange: [28000, 95000]
    },
    "Western & Grill": {
        bases: [
            "Sirloin Steak", "Ribeye Steak", "Tenderloin Steak", "Wagyu Meltique MB7", "T-Bone Steak",
            "Grilled Salmon Fillet", "BBQ Beef Ribs", "Smoked Brisket", "Classic Cheeseburger",
            "Double Bacon Gourmet Burger", "Grilled Chicken Breast", "Fish & Chips Crispy",
            "Lamb Chop Herb-Crusted", "Crispy Chicken Schnitzel", "Pulled Beef Sandwich",
            "Philly Cheese Steak", "Surf & Turf Deluxe", "Grilled Bratwurst Sausage",
            "Beef Wellington Slice", "Barbecue Pulled Pork Style Chicken"
        ],
        styles: [
            "Daging Pilihan dengan Saus Mushroom Truffle", "Dipanggang Sempurna dengan Saus Blackpepper",
            "Dengan Garlic Butter Melted & Rosemary", "Disiram Saus BBQ Karamel Smokey",
            "Saus Chimichurri Segar Khas Argentina", "Dengan Creamy Peppercorn Glaze",
            "Baluran Keju Cheddar Meleleh & Bawang Karamel", "Dengan Honey Mustard Dressing",
            "Gaya Klasik Texas Wood-Smoked", "Pilihan Tingkat Kematangan Medium Rare Juiciness"
        ],
        desc: "Potongan daging premium berkualitas tinggi yang dipanggang dengan teknik artisanal, menghadirkan kelembutan maksimal dan aroma smokey yang menggoda selera.",
        priceRange: [65000, 285000]
    },
    "Pasta & Pizza": {
        bases: [
            "Spaghetti Carbonara", "Fettuccine Alfredo", "Penne Arrabbiata", "Spaghetti Aglio Olio",
            "Lasagna Al Forno", "Ravioli Ricotta & Spinach", "Tagliatelle Bolognese", "Fusilli Pesto Basil",
            "Macaroni Four Cheese", "Spaghetti Pescatore Seafood", "Gnocchi Saus Mentega Sage",
            "Pizza Margherita Artisan", "Pizza Pepperoni Supreme", "Pizza Quattro Formaggi",
            "Pizza Meat Lovers", "Pizza Truffle & Wild Mushroom", "Pizza BBQ Chicken Smoke",
            "Calzone Lipat Speciale", "Pizza Marinara Klasik Napoli", "Spaghetti Truffle Cream"
        ],
        styles: [
            "Dengan Taburan Grana Padano & Minyak Truffle Asli", "Topping Mozzarella Meleleh Melimpah",
            "Sentuhan Bawang Putih, Cabe Kering, & Extra Virgin Olive Oil", "Daging Sapi Cincang Slow-Cooked 6 Jam",
            "Saus Tomat San Marzano Khas Italia Asli", "Sentuhan Creamy Bechamel & Keju Panggang Emas",
            "Potongan Smoked Beef & Parmesan Segar", "Gaya Tradisional Tipis Renyah Wood-Fired",
            "Saus Kemangi Segar dengan Topping Kacang Kenari", "Pilihan Udang Segar & Cumi Calamari"
        ],
        desc: "Pasta buatan tangan dan pizza crust fermentasi alami, dipadu keju import premium dan rempah oregano Mediterania untuk cita rasa otentik Italia.",
        priceRange: [42000, 145000]
    },
    "Asian & Japanese": {
        bases: [
            "Tori Paitan Ramen", "Shoyu Beef Ramen", "Spicy Miso Ramen", "Chicken Katsu Curry",
            "Beef Yakiniku Donburi", "Salmon Teriyaki Rice Bowl", "Gyu Don Wagyu", "Chicken Teriyaki",
            "Tom Yum Seafood Thailand", "Pad Thai Kung Udang Segar", "Nasi Hainan Ayam Panggang",
            "Ayam Kung Pao Khas Sichuan", "Sapi Mongolian Wok-Fried", "Dimsum Hakau Udang",
            "Dimsum Siomay Ayam Udang", "Salmon Nigiri Sushi", "Aburi Salmon Mentai Roll",
            "Dragon Roll Avocado", "Crispy Tempura Moriawase", "Kwetiau Sapi Siram Telur"
        ],
        styles: [
            "Kuah Kaldu Kolagen Gurih 12 Jam", "Saus Mentai Bakar Flamed Mayo",
            "Bumbu Manis Gurih Wijen Teriyaki", "Pedas Gurih Saus Mala Sichuan",
            "Kari Kental Jepang dengan Wortel & Kentang Manis", "Lapisan Kulit Nori Renyah & Tobiko Emas",
            "Irisan Daun Bawang, Jamur Narutomaki & Telur Ajitsuke Tamago", "Aroma Wok-Hei Api Besar Restoran Asia",
            "Saus Manis Asin Dashi dengan Onsen Egg Lumer", "Kombinasi Saus Sambal Bangkok & Perasan Jeruk Nipis"
        ],
        desc: "Kreasi kuliner Asia terfavorit dengan teknik memasak otentik, memadukan bumbu khas oriental dan kesegaran bahan baku untuk ledakan rasa di setiap gigitan.",
        priceRange: [35000, 135000]
    },
    "Seafood": {
        bases: [
            "Kepiting Tarakan", "Lobster Air Tawar", "Udang Windu Jumbo", "Udang Vaname",
            "Cumi-Cumi Segar", "Ikan Gurame Segar", "Ikan Kerapu Bintang", "Ikan Kakap Merah",
            "Ikan Bawal Jepang", "Kerang Saus Padang", "Kerang Dara Rebus", "Kerang Hijau Garlic",
            "Seafood Platter Combo", "Baby Octopus / Gurita Panggang", "Ikan Baronang Bakar"
        ],
        styles: [
            "Saus Padang Pedas Gurih Kental", "Saus Lada Hitam Pedas Menggigit",
            "Bakar Madu Karamel Wangi Asap", "Goreng Tepung Calamari Super Crispy",
            "Saus Telur Asin Creamy Melimpah", "Bumbu Jimbaran Pedas Manis",
            "Steam Garlic Jahe Bumbu Hong Kong", "Saus Asam Manis Nanas Segar",
            "Saus Butter Lemon Garam Laut", "Bakar Rica-Rica Cabe Rawit Segar"
        ],
        desc: "Tangkapan laut segar harian langsung dari nelayan, diolah higienis dengan bumbu rempah aromatik menciptakan perpaduan rasa laut yang manis dan gurih alami.",
        priceRange: [48000, 290000]
    },
    "Dessert & Pastry": {
        bases: [
            "Molten Choco Lava Cake", "Classic Tiramisu Mascarpone", "New York Cheesecake",
            "Waffle Belgia Crispy", "Fluffy Souffle Pancake", "Pisang Bakar Keju Aren",
            "Martabak Manis Roll", "Croissant Mentega Perancis", "Churros Saus Cokelat Belgia",
            "Panna Cotta Vanilla Madu", "Creme Brulee Karamel", "Apple Pie Cinnamon",
            "Brownies Fudge Almond", "Mochi Gelato Isi 3", "Gelato Double Scoop Artisan",
            "Poffertjes Gula Halus", "Es Cendol Durian Montong", "Es Campur Signature Royal"
        ],
        styles: [
            "Dengan Es Krim Vanilla Bean Madagaskar", "Taburan Cokelat Callebaut Belgia",
            "Kombinasi Karamel Asin & Taburan Sea Salt Flakes", "Siraman Gula Aren Organik & Keju Parut",
            "Saus Matcha Kyoto & Red Bean Manis", "Lapisan Vla Keju Mascarpone Lembut",
            "Garnish Buah Strawberry Segar & Daun Mint", "Taburan Kacang Hazelnut Panggang Gurih",
            "Topping Oreo Crumbles & Marshmallow Melted", "Baluran Gula Kayu Manis Hangat Khas Spanyol"
        ],
        desc: "Sajian penutup istimewa penuh kelembutan dan rasa manis yang seimbang, dibuat fresh setiap hari oleh pastry chef profesional restoran kami.",
        priceRange: [22000, 68000]
    },
    "Beverages & Coffee": {
        bases: [
            "Kopi Susu Signature Aren", "Caffe Latte Double Shot", "Cappuccino Foam Velvet",
            "Caramel Macchiato", "Americano Arabica Single Origin", "Espresso Tonic Soda",
            "Avocado Coffee Float", "Matcha Latte Ceremonial", "Taro Milkshake Velvet",
            "Es Teh Tarik Klasik", "Earl Grey Milk Tea", "Es Teh Pandan Wangi",
            "Mocktail Sunset Sunrise", "Mojito Lime & Fresh Mint", "Lychee Iced Tea Segar",
            "Peach Iced Tea Selasih", "Jus Alpukat Kocok Cokelat", "Jus Mangga Gedong Gincu",
            "Jus Strawberry Jeruk Segar", "Dragonfruit Banana Smoothie"
        ],
        styles: [
            "Dengan Biji Kopi Arabika Pilihan", "Topping Boba Brown Sugar Kenyal",
            "Sentuhan Daun Mint & Soda Menyegarkan", "Campuran Susu Oat Barista Friendly",
            "Sirup Monin Import & Irisan Lemon Segar", "Espresso Dingin dengan Sentuhan Krim Macchiato",
            "Dingin Menyegarkan dengan Es Kristal Murni", "Pemanis Madu Murni Alami",
            "Kombinasi Buah Tropis Asli Tanpa Pengawet", "Taburan Bubuk Kayu Manis di Atas Busa Lembut"
        ],
        desc: "Minuman pelepas dahaga dari racikan barista andalan menggunakan bahan-bahan grade A dan biji kopi pilihan nusantara dengan aroma memikat.",
        priceRange: [18000, 48000]
    },
    "Snacks & Appetizers": {
        bases: [
            "Truffle Parmesan French Fries", "Tahu Walik Banyuwangi", "Crispy Chicken Wings",
            "Risoles Smoked Beef Mayo", "Bitterballen Keju Belanda", "Nachos Guacamole Supreme",
            "Crispy Onion Rings", "Calamari Ring Tartar Saus", "Spring Roll Udang Sayur",
            "Mozzarella Sticks Tarik", "Singkong Goreng Garlic Keju", "Dimsum Kulit Tahu Crispy",
            "Bala-Bala Gurih Renyah", "Pisang Goreng Wijen Madu", "Potato Wedges Herbs Dip"
        ],
        styles: [
            "Dengan Saus Cocolan Garlic Aioli", "Taburan Bubuk Jagung Bakar Pedas",
            "Bumbu Spicy BBQ Smokey", "Saus Sambal Kecap Cabe Rawit",
            "Dibalut Keju Meleleh Molor Maksimal", "Saus Keju Cheddar Meleleh Hangat",
            "Minyak Truffle Asli & Rempah Parsley", "Kombinasi Saus Tartar Segar Lemon",
            "Bumbu Daun Jeruk Pedas Gurih", "Crispy Batter Gurih Keemasan"
        ],
        desc: "Camilan pembuka renyah nan gurih yang cocok dinikmati bersama teman atau keluarga sambil menunggu hidangan utama disajikan.",
        priceRange: [20000, 52000]
    },
    "Healthy & Salad": {
        bases: [
            "Caesar Salad Grilled Chicken", "Smoked Salmon Avocado Bowl", "Greek Salad Feta Cheese",
            "Quinoa Salad Bowl", "Thai Beef Salad Spicy Lime", "Warm Mushroom Salad",
            "Tuna Nicoise Salad", "Crispy Tofu Sesame Salad", "Açai Berry Superfood Bowl",
            "Green Goddess Protein Bowl", "Roasted Beetroot & Goat Cheese Bowl", "Garden Fresh Mesclun Salad"
        ],
        styles: [
            "Dengan Homemade Caesar Dressing & Roti Crouton", "Dressing Extra Virgin Olive Oil & Lemon",
            "Saus Wijen Sangrai Khas Jepang (Roasted Sesame)", "Dressing Honey Balsamic Glaze Segar",
            "Topping Biji Chia, Almond Panggang & Granola", "Perasan Jeruk Nipis & Minyak Ikan Dressing",
            "Dressing Alpukat Herb Segar Kaya Lemak Sehat", "Taburan Keju Feta & Buah Zaitun Hitam",
            "Dengan Telur Rebus Lembut Setengah Matang", "Potongan Alpukat Mentega Matang Sempurna"
        ],
        desc: "Kombinasi sayuran hidroponik segar, protein bernutrisi, dan dressing sehat alami tanpa pengawet untuk gaya hidup seimbang dan berenergi.",
        priceRange: [38000, 92000]
    },
    "Soup & Hotpot": {
        bases: [
            "Sop Iga Sapi Kuah Bening", "Sop Buntut Rempah Spesial", "Tom Yum Goong Seafood",
            "Creamy Wild Mushroom Soup", "Clam Chowder Roti Sourdough", "Sup Jagung Manis Kepiting",
            "Sup Kimlo Solo Komplit", "Sup Ayam Jahe Herbal", "Beef Sukiyaki Hotpot",
            "Seafood Collagen Nabe", "Sop Kaki Sapi Kuah Susu", "Sup Ikan Salmon Kuah Asam"
        ],
        styles: [
            "Kuah Bening Gurih Kaldu Tulang Sapi 8 Jam", "Kuah Santan Susu Gurih Aromatik Pala & Cengkeh",
            "Kuah Asam Pedas Segar dengan Daun Ketumbar & Serai", "Sajian Hangat dengan Bawang Goreng & Irisan Jeruk Nipis",
            "Kuah Kental Creamy Disajikan dengan Garlic Bread", "Kaldu Sayur Bening dengan Jamur Kuping & Sedap Malam",
            "Kuah Dashi Manis Gurih dengan Tofu Lembut", "Kaldu Pedas Mala Merah Menggugah Selera",
            "Kuah Kuning Asam Segar Khas Manado", "Taburan Seledri Segar & Emping Melinjo Renyah"
        ],
        desc: "Sup hangat berkaldu kaya rasa yang dimasak perlahan dengan rempah alami pilihan, menghangatkan tubuh dan memanjakan lidah di setiap sendokannya.",
        priceRange: [35000, 115000]
    }
};

const badgePool = [
    null, null, "Best Seller", "Chef Recomended", "Favorit", "Must Try",
    "Promo 20%", "Pedas Mantap 🔥", "Signature", "Menu Baru ⭐"
];

function generate1000MenuItems() {
    const items = [];
    const categories = Object.keys(categoryTemplates);
    let idCounter = 1;

    // We will distribute the 1000 items evenly across the 10 categories: 100 items per category
    for (const catName of categories) {
        const catData = categoryTemplates[catName];
        const bases = catData.bases;
        const styles = catData.styles;
        const minPrice = catData.priceRange[0];
        const maxPrice = catData.priceRange[1];

        let countForCat = 0;
        let baseIndex = 0;
        let styleIndex = 0;

        while (countForCat < 100) {
            const base = bases[baseIndex % bases.length];
            const style = styles[styleIndex % styles.length];
            
            // Build unique, natural menu name
            let name = "";
            const variationType = countForCat % 5;
            if (variationType === 0) {
                name = `${base} ${style}`;
            } else if (variationType === 1) {
                name = `${base} Signature (${style})`;
            } else if (variationType === 2) {
                name = `${base} Spesial - ${style}`;
            } else if (variationType === 3) {
                name = `Royal ${base} ${style}`;
            } else {
                name = `${base} Premium ${style}`;
            }

            // Price calculation (rounded to thousands)
            const priceStep = 1000;
            const randomFactor = Math.random();
            let rawPrice = minPrice + randomFactor * (maxPrice - minPrice);
            let roundedPrice = Math.round(rawPrice / priceStep) * priceStep;

            // Rating between 4.3 and 5.0
            const rating = (4.3 + Math.random() * 0.7).toFixed(1);

            // Total sales between 15 and 3200
            const totalTerjual = Math.floor(15 + Math.random() * 2500);

            // Badge
            const badge = badgePool[Math.floor(Math.random() * badgePool.length)];

            // Prep time between 8 and 35 mins
            const estimasiMenit = 10 + Math.floor(Math.random() * 20);

            // Calories between 120 and 850
            const kalori = Math.floor(150 + Math.random() * 650);

            // Match image pool accurately based on the specific base dish & category
            const matchedPool = resolveDishImagePool(base, catName);
            const baseImg = matchedPool[countForCat % matchedPool.length];
            const imgUrl = `${baseImg}&sig=${countForCat + 1}`;

            // Rich description
            const deskripsi = `${catData.desc} Dihidangkan istimewa dengan ${style.toLowerCase()}. Porsi pas, higienis, dan terbuat dari bahan-bahan bermutu tinggi.`;

            items.push({
                nama: name,
                deskripsi: deskripsi,
                kategori: catName,
                harga: roundedPrice,
                rating: parseFloat(rating),
                total_terjual: totalTerjual,
                badge: badge,
                is_tersedia: 1,
                kalori: kalori,
                estimasi_menit: estimasiMenit,
                gambar: imgUrl
            });

            countForCat++;
            baseIndex++;
            if (baseIndex % bases.length === 0) {
                styleIndex++;
            }
        }
    }

    return items;
}

async function seed() {
    console.log("Starting menu seeder for 1,000 items...");
    const items = generate1000MenuItems();
    console.log(`Generated ${items.length} unique items across categories!`);

    try {
        // Clear existing items in menu to guarantee clean 1,000 items
        await db.query("SET FOREIGN_KEY_CHECKS = 0;");
        await db.query("TRUNCATE TABLE menu;");
        await db.query("SET FOREIGN_KEY_CHECKS = 1;");
        console.log("Truncated menu table cleanly.");

        // Insert in batches of 100 for high performance
        const batchSize = 100;
        for (let i = 0; i < items.length; i += batchSize) {
            const batch = items.slice(i, i + batchSize);
            const values = batch.map(item => [
                item.nama,
                item.deskripsi,
                item.kategori,
                item.harga,
                item.rating,
                item.total_terjual,
                item.badge,
                item.is_tersedia,
                item.kalori,
                item.estimasi_menit,
                item.gambar
            ]);

            await db.query(
                `INSERT INTO menu (
                    nama, deskripsi, kategori, harga, rating, 
                    total_terjual, badge, is_tersedia, kalori, 
                    estimasi_menit, gambar
                ) VALUES ?`,
                [values]
            );
            console.log(`Inserted items ${i + 1} to ${Math.min(i + batchSize, items.length)}`);
        }

        const [cnt] = await db.query("SELECT COUNT(*) as count FROM menu;");
        console.log(`SUCCESS! Total menu items in database: ${cnt[0].count}`);
        process.exit(0);
    } catch (err) {
        console.error("Seeding error:", err);
        process.exit(1);
    }
}

if (require.main === module) {
    seed();
}

module.exports = { generate1000MenuItems, seed };
